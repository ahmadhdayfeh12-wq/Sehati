# Hawiya · هوية — digital medical identity (MVP)

A secure medical profile per patient, reachable through a QR card that holds **only a random token**.
Families (often abroad) manage the profile, verified doctors request access, the family approves, and every access is logged.

Stack: Node.js 22+ (no npm dependencies), built-in SQLite, vanilla JS front end. Arabic (RTL) and English (LTR).

## Run locally (2 minutes)
```bash
node -v                  # must be 22.13 or newer
npm run seed             # FAKE demo accounts (never in production)
npm start                # http://localhost:3000
npm test                 # i18n check + 45 end-to-end security checks
```
Demo logins (password `Demo-Passw0rd!`): `family@demo.test`, `doctor@demo.test`, `pending-doctor@demo.test`, `admin@demo.test`.
Try it: sign in as family → open the profile → *QR card* → copy the link → sign in as the doctor in a private window and open that link → request access → approve as family.

## Publish with a permanent public URL

### Option A, Render (simplest, about 15 minutes, ~US$7/month)
1. Put this folder in a private GitHub repository.
2. Generate your secret and **store it in a password manager**:
   `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
   Losing it makes every uploaded document and QR card unrecoverable.
3. On render.com: **New → Blueprint**, select the repository (it reads `render.yaml`; a paid plan is required for the persistent disk).
4. Enter the environment values: `BASE_URL` (the https URL you will use), `DATA_KEY`, `ADMIN_EMAIL`, `ADMIN_PASSWORD` (12+ characters).
5. After deploy you get `https://hawiya.onrender.com`. For your own domain: **Settings → Custom Domains**, add `app.your-domain.com`, create the CNAME record Render shows, wait for the certificate. Then set `BASE_URL` to that exact address and redeploy. (Printed QR cards contain `BASE_URL`, so decide your final domain **before** printing cards.)

### Option B, your own server (any VPS, ~US$5/month, e.g. Hetzner, DigitalOcean)
```bash
git clone <your repo> && cd hawiya
cp .env.example .env && nano .env          # fill the 4 values
nano Caddyfile                              # put your domain
docker compose up -d --build                # HTTPS certificate is automatic
```
Point your domain's A record at the server first. Updates: `git pull && docker compose up -d --build`.

The server **refuses to start in production** without `DATA_KEY`, an `https://` `BASE_URL` and admin credentials.

## Backups (do this before any real user)
`DATA_DIR=/data ./scripts/backup.sh /backups` makes a consistent database copy plus an archive of uploads. Run it daily from cron and copy the output **off the server**. Test a restore once.

## What is implemented
Family/patient/caregiver/doctor/admin accounts · profiles, chronic conditions, allergies, medications, emergency contacts · random-token QR codes (rotatable) · bilingual printable card · doctor verification by admin · consent flow (request → approve for 24 h/7 d/30 d → revoke) · audited emergency access with mandatory reason, minimal data · patient-visible access history · tamper-evident (hash-chained) audit log · PDF/PNG/JPEG upload with content sniffing and AES-256-GCM encryption at rest · CSRF protection, strict CSP, scrypt password hashing, login lockout and rate limits, admins cannot read medical data.

## Not implemented yet (be honest with hospitals and investors)
- **Subscriptions and payments** (Stripe or a Lebanese-friendly processor), pricing page
- Email verification, password reset, two-factor authentication, SMS/WhatsApp alerts when a card is scanned
- Doctors adding clinical notes; lab-result trends; vaccination and appointment history; French
- SQLite means **one server instance**; move to PostgreSQL (and Redis for rate limits) before scaling out
- Database fields are not column-encrypted (files and QR tokens are); use full-disk encryption on the host
- A premium Arabic typeface: the app uses each device's best system Arabic font. To bundle one (e.g. IBM Plex Sans Arabic, OFL license), add the font files to `public/fonts` and an `@font-face` in `style.css`.

## Before real patient data (not optional)
1. Lawyer review in Lebanon (health-data consent, Law 81/2018 on electronic transactions and personal data) and for each future market (GDPR for EU diaspora users).
2. Independent security review / penetration test.
3. Terms, privacy policy, and a process for patient data requests and deletion.
4. A doctor verification procedure (check the Order of Physicians registry), not just the admin button.
5. Monitoring, uptime alerts, restore drill.
