// Creates FAKE demo data for development. Never put real patient data in a development database.
import { cfg } from './config.js';
import { one, run, createUser, createPatient, audit } from './db.js';
import * as L from './lib.js';

if (cfg.production) { console.error('Demo data must never be created in production.'); process.exit(1); }
const PW = 'Demo-Passw0rd!';
const pw = await L.hashPw(PW);
const mk = (u) => one('SELECT id FROM users WHERE email=?', u.email)?.id ?? createUser({ ...u, pw });

const admin = mk({ email: 'admin@demo.test', role: 'admin', name: 'Demo Admin' });
const doc = mk({ email: 'doctor@demo.test', role: 'doctor', name: 'Dr. Demo Doctor', license_no: 'DEMO-0001', specialty: 'Internal medicine', facility: 'Demo Hospital, Tripoli', doc_status: 'approved' });
mk({ email: 'pending-doctor@demo.test', role: 'doctor', name: 'Dr. Pending Example', license_no: 'DEMO-0002', specialty: 'Cardiology', facility: 'Demo Clinic, Tripoli', doc_status: 'pending' });
const cg = mk({ email: 'family@demo.test', role: 'caregiver', name: 'Demo Family Member', phone: '+10000000000' });

if (!one('SELECT 1 FROM members WHERE user_id=?', cg)) {
  const pid = createPatient(cg, { full_name: 'Fatima Demo Test', dob: '1948-03-14', blood_group: 'O+', city: 'Tripoli', warnings: 'Takes a blood thinner. Avoid NSAIDs. (FAKE DEMO DATA)' });
  run("INSERT INTO conditions(patient_id,name,diagnosed_year,status) VALUES(?,?,?,'active')", pid, 'Type 2 diabetes', 2009);
  run("INSERT INTO conditions(patient_id,name,diagnosed_year,status) VALUES(?,?,?,'active')", pid, 'Hypertension', 2004);
  run("INSERT INTO allergies(patient_id,substance,reaction,severity) VALUES(?,?,?,?)", pid, 'Penicillin', 'Rash, swelling', 'severe');
  run("INSERT INTO medications(patient_id,name,dose,frequency,route,start_date,prescriber,active) VALUES(?,?,?,?,?,?,?,1)", pid, 'Metformin', '500 mg', 'Twice daily', 'oral', '2012-05-01', 'Dr. Demo Doctor');
  run("INSERT INTO medications(patient_id,name,dose,frequency,route,start_date,prescriber,active) VALUES(?,?,?,?,?,?,?,1)", pid, 'Warfarin', '3 mg', 'Once daily (evening)', 'oral', '2020-01-10', 'Dr. Demo Doctor');
  run("INSERT INTO contacts(patient_id,name,relation,phone,is_primary) VALUES(?,?,?,?,1)", pid, 'Demo Son (abroad)', 'Son', '+10000000000');
  audit({ id: admin, role: 'admin' }, pid, 'seed', null, 'local');
}
console.log(`Demo accounts created (password for all: ${PW})
  admin@demo.test            administrator
  doctor@demo.test           verified doctor
  pending-doctor@demo.test   doctor awaiting verification
  family@demo.test           caregiver with one fake patient (Fatima Demo Test)`);
