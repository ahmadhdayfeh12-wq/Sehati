import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
// Vendored MIT-licensed QR encoder (Kazuhiko Arase, via qrcode-terminal). See server/vendor/qrcode.
const QRCode = require('./vendor/qrcode/index.js');
const EC = require('./vendor/qrcode/QRErrorCorrectLevel.js');

export function qrSvg(text) {
  const qr = new QRCode(-1, EC.Q); // level Q: tolerates ~25% damage, good for worn cards and bracelets
  qr.addData(text);
  qr.make();
  const n = qr.getModuleCount();
  const q = 4; // quiet zone
  let d = '';
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (qr.isDark(r, c)) d += `M${c + q} ${r + q}h1v1h-1z`;
  const s = n + q * 2;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${s} ${s}" shape-rendering="crispEdges" role="img" aria-label="QR"><rect width="${s}" height="${s}" fill="#fff"/><path d="${d}" fill="#000"/></svg>`;
}
