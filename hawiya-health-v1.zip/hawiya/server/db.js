import { DatabaseSync } from 'node:sqlite';
import path from 'node:path';
import { cfg, DATA_KEY } from './config.js';
import * as L from './lib.js';

export const db = new DatabaseSync(path.join(cfg.dataDir, 'hawiya.db'));
db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');

db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, pw TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN('patient','caregiver','doctor','admin')),
  name TEXT NOT NULL, phone TEXT, license_no TEXT, specialty TEXT, facility TEXT,
  doc_status TEXT CHECK(doc_status IN('pending','approved','rejected')), doc_note TEXT,
  failed INTEGER NOT NULL DEFAULT 0, locked_until TEXT, disabled INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(
  id TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  csrf TEXT NOT NULL, created_at TEXT NOT NULL, expires_at TEXT NOT NULL, ip TEXT, ua TEXT);
CREATE TABLE IF NOT EXISTS patients(
  id INTEGER PRIMARY KEY, full_name TEXT NOT NULL, dob TEXT, blood_group TEXT, city TEXT, warnings TEXT,
  created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL,
  qr_hash TEXT UNIQUE NOT NULL, qr_enc TEXT NOT NULL, qr_rotated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS members(
  patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  relation TEXT NOT NULL CHECK(relation IN('owner','caregiver')), PRIMARY KEY(patient_id,user_id));
CREATE TABLE IF NOT EXISTS conditions(
  id INTEGER PRIMARY KEY, patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  name TEXT NOT NULL, diagnosed_year INTEGER, status TEXT NOT NULL DEFAULT 'active', notes TEXT);
CREATE TABLE IF NOT EXISTS allergies(
  id INTEGER PRIMARY KEY, patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  substance TEXT NOT NULL, reaction TEXT, severity TEXT);
CREATE TABLE IF NOT EXISTS medications(
  id INTEGER PRIMARY KEY, patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  name TEXT NOT NULL, dose TEXT, frequency TEXT, route TEXT, start_date TEXT, end_date TEXT,
  prescriber TEXT, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS contacts(
  id INTEGER PRIMARY KEY, patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  name TEXT NOT NULL, relation TEXT, phone TEXT NOT NULL, is_primary INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS documents(
  id INTEGER PRIMARY KEY, patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  title TEXT NOT NULL, category TEXT, mime TEXT NOT NULL, size INTEGER NOT NULL, file TEXT NOT NULL,
  uploaded_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS grants(
  id INTEGER PRIMARY KEY, patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  doctor_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status TEXT NOT NULL CHECK(status IN('pending','active','denied','revoked')),
  requested_at TEXT NOT NULL, decided_at TEXT, expires_at TEXT);
CREATE TABLE IF NOT EXISTS audit(
  id INTEGER PRIMARY KEY, ts TEXT NOT NULL, actor_id INTEGER, actor_role TEXT, patient_id INTEGER,
  action TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '', ip TEXT, prev_hash TEXT NOT NULL, hash TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS audit_patient ON audit(patient_id, id);
CREATE INDEX IF NOT EXISTS grants_lookup ON grants(patient_id, doctor_id, status);
`);

const nn = (a) => a.map((v) => (v === undefined ? null : v));
export const one = (sql, ...p) => db.prepare(sql).get(...nn(p));
export const all = (sql, ...p) => db.prepare(sql).all(...nn(p));
export const run = (sql, ...p) => db.prepare(sql).run(...nn(p));
export function tx(fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; }
}
export const now = () => new Date().toISOString();

// ---- Tamper-evident audit log: every row's hash covers the previous row's hash. ----
const chain = (prev, r) => L.sha256([prev, r.ts, r.actor_id, r.actor_role, r.patient_id, r.action, r.detail, r.ip].join('|'));

export function audit(actor, patientId, action, detail, ip) {
  const row = {
    ts: now(), actor_id: actor?.id ?? null, actor_role: actor?.role ?? null, patient_id: patientId ?? null,
    action, detail: detail ? JSON.stringify(detail) : '', ip: ip || '',
  };
  const prev = one('SELECT hash FROM audit ORDER BY id DESC LIMIT 1')?.hash || 'GENESIS';
  run('INSERT INTO audit(ts,actor_id,actor_role,patient_id,action,detail,ip,prev_hash,hash) VALUES(?,?,?,?,?,?,?,?,?)',
    row.ts, row.actor_id, row.actor_role, row.patient_id, row.action, row.detail, row.ip, prev, chain(prev, row));
}
export function verifyAudit() {
  let prev = 'GENESIS', n = 0;
  for (const r of all('SELECT * FROM audit ORDER BY id')) {
    if (r.prev_hash !== prev || r.hash !== chain(prev, r)) return { ok: false, checked: n, brokenAt: r.id };
    prev = r.hash; n++;
  }
  return { ok: true, checked: n };
}

// ---- Models ----
export function createUser(u) {
  const r = run('INSERT INTO users(email,pw,role,name,phone,license_no,specialty,facility,doc_status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',
    u.email, u.pw, u.role, u.name, u.phone, u.license_no, u.specialty, u.facility,
    u.role === 'doctor' ? (u.doc_status || 'pending') : null, now());
  return Number(r.lastInsertRowid);
}

// The QR holds ONLY a random 256-bit token. We store its hash (for lookup) and an encrypted copy (so the family can reprint the card).
export function createPatient(userId, p, relation = 'owner') {
  const token = L.rand(32);
  const r = run('INSERT INTO patients(full_name,dob,blood_group,city,warnings,created_by,created_at,qr_hash,qr_enc,qr_rotated_at) VALUES(?,?,?,?,?,?,?,?,?,?)',
    p.full_name, p.dob, p.blood_group, p.city, p.warnings, userId, now(),
    L.sha256(token), L.encBuf(Buffer.from(token), DATA_KEY).toString('base64'), now());
  const id = Number(r.lastInsertRowid);
  run('INSERT INTO members(patient_id,user_id,relation) VALUES(?,?,?)', id, userId, relation);
  return id;
}
export function rotateQr(patientId) {
  const token = L.rand(32);
  run('UPDATE patients SET qr_hash=?, qr_enc=?, qr_rotated_at=? WHERE id=?',
    L.sha256(token), L.encBuf(Buffer.from(token), DATA_KEY).toString('base64'), now(), patientId);
  return token;
}
export const qrToken = (p) => L.decBuf(Buffer.from(p.qr_enc, 'base64'), DATA_KEY).toString();
