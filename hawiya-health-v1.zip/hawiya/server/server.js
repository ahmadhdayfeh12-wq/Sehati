import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { cfg, DATA_KEY } from './config.js';
import { one, all, run, tx, now, audit, verifyAudit, createUser, createPatient, rotateQr, qrToken } from './db.js';
import * as L from './lib.js';
import { qrSvg } from './qr.js';

// ---------- helpers ----------
class HttpError extends Error { constructor(status, code) { super(code); this.status = status; this.code = code; } }
const bad = (code = 'invalid') => new HttpError(400, code);
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.ttf': 'font/ttf', '.woff2': 'font/woff2' };
const BLOOD = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
const EMERGENCY_REASONS = ['unconscious', 'cardiac', 'respiratory', 'trauma', 'confused', 'other'];

const S = (v, max = 200, req = false) => {
  if (v == null || v === '') { if (req) throw bad('missing'); return null; }
  if (typeof v !== 'string') throw bad();
  v = v.trim();
  if (!v) { if (req) throw bad('missing'); return null; }
  if (v.length > max) throw bad('too_long');
  return v;
};
const D = (v) => { if (v == null || v === '') return null; if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v) || isNaN(Date.parse(v))) throw bad('invalid_date'); return v; };
const PH = (v, req) => { v = S(v, 30, req); if (v && !/^[+\d][\d\s().-]{4,}$/.test(v)) throw bad('invalid_phone'); return v; };
const E = (v, list, def = null) => { if (v == null || v === '') return def; if (!list.includes(v)) throw bad(); return v; };
const Y = (v) => { if (v == null || v === '') return null; const n = Number(v); if (!Number.isInteger(n) || n < 1900 || n > new Date().getFullYear()) throw bad('invalid_year'); return n; };
const B = (v) => (v === true || v === 1 || v === '1' || v === 'on' ? 1 : 0);
const EMAIL = (v) => { v = S(v, 254, true).toLowerCase(); if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) throw bad('invalid_email'); return v; };

const KINDS = {
  conditions: { table: 'conditions', spec: (b) => ({ name: S(b.name, 120, true), diagnosed_year: Y(b.diagnosed_year), status: E(b.status, ['active', 'resolved'], 'active'), notes: S(b.notes, 500) }) },
  allergies: { table: 'allergies', spec: (b) => ({ substance: S(b.substance, 120, true), reaction: S(b.reaction, 200), severity: E(b.severity, ['mild', 'moderate', 'severe']) }) },
  medications: { table: 'medications', spec: (b) => ({ name: S(b.name, 120, true), dose: S(b.dose, 60), frequency: S(b.frequency, 80), route: E(b.route, ['oral', 'injection', 'inhaled', 'topical', 'drops', 'other']), start_date: D(b.start_date), end_date: D(b.end_date), prescriber: S(b.prescriber, 120), active: B(b.active) }) },
  contacts: { table: 'contacts', spec: (b) => ({ name: S(b.name, 120, true), relation: S(b.relation, 60), phone: PH(b.phone, true), is_primary: B(b.is_primary) }) },
};

const mask = (name) => { const p = String(name).trim().split(/\s+/); return p.length < 2 ? p[0] : `${p[0]} ${[...p[p.length - 1]][0]}.`; };
const age = (dob) => { if (!dob) return null; const d = new Date(dob), t = new Date(); let a = t.getFullYear() - d.getFullYear(); if (t < new Date(t.getFullYear(), d.getMonth(), d.getDate())) a--; return a; };

// ---------- rate limiting (in-memory; use Redis if you run several instances) ----------
const hits = new Map();
function limit(key, max, windowMs) {
  const t = Date.now(), arr = (hits.get(key) || []).filter((x) => t - x < windowMs);
  if (arr.length >= max) throw new HttpError(429, 'rate_limited');
  arr.push(t); hits.set(key, arr);
}
setInterval(() => { const t = Date.now(); for (const [k, v] of hits) if (!v.some((x) => t - x < 3600e3)) hits.delete(k); }, 600e3).unref();

// ---------- sessions ----------
const SESSION_IDLE = 12 * 3600e3, SESSION_MAX = 7 * 86400e3;
const parseCookies = (req) => Object.fromEntries((req.headers.cookie || '').split(';').map((c) => c.trim().split('=')).filter((x) => x[0]).map(([k, ...v]) => [k, v.join('=')]));
function cookie(res, val, maxAge) {
  res.setHeader('Set-Cookie', `sid=${val}; HttpOnly; Path=/; SameSite=Strict; Max-Age=${maxAge}${cfg.secure ? '; Secure' : ''}`);
}
function startSession(req, res, ip, userId) {
  const token = L.rand(32), csrf = L.rand(24);
  run('INSERT INTO sessions(id,user_id,csrf,created_at,expires_at,ip,ua) VALUES(?,?,?,?,?,?,?)',
    L.sha256(token), userId, csrf, now(), new Date(Date.now() + SESSION_IDLE).toISOString(), ip, String(req.headers['user-agent'] || '').slice(0, 200));
  cookie(res, token, SESSION_IDLE / 1000);
}
function getSession(req) {
  const sid = parseCookies(req).sid;
  if (!sid) return null;
  const s = one('SELECT * FROM sessions WHERE id=?', L.sha256(sid));
  if (!s) return null;
  if (s.expires_at < now() || Date.parse(s.created_at) + SESSION_MAX < Date.now()) { run('DELETE FROM sessions WHERE id=?', s.id); return null; }
  const user = one('SELECT id,email,role,name,phone,license_no,specialty,facility,doc_status,doc_note FROM users WHERE id=? AND disabled=0', s.user_id);
  if (!user) return null;
  run('UPDATE sessions SET expires_at=? WHERE id=?', new Date(Date.now() + SESSION_IDLE).toISOString(), s.id);
  return { s, user: { ...user } };
}

// ---------- body ----------
function readBody(req, max) {
  return new Promise((ok, fail) => {
    const chunks = []; let n = 0, over = false;
    req.on('data', (c) => { n += c.length; if (n > max) over = true; else chunks.push(c); });
    req.on('end', () => (over ? fail(new HttpError(413, 'too_large')) : ok(Buffer.concat(chunks))));
    req.on('error', fail);
  });
}

// ---------- access control ----------
function member(ctx, pid) {
  if (!['patient', 'caregiver'].includes(ctx.user.role)) throw new HttpError(403, 'forbidden');
  const m = one('SELECT relation FROM members WHERE patient_id=? AND user_id=?', pid, ctx.user.id);
  if (!m) throw new HttpError(404, 'not_found'); // 404, not 403: do not reveal that the profile exists
  return m;
}
function needVerifiedDoctor(ctx) {
  if (ctx.user.role !== 'doctor') throw new HttpError(403, 'forbidden');
  if (ctx.user.doc_status !== 'approved') throw new HttpError(403, 'doctor_not_verified');
}
const activeGrant = (pid, did) => one("SELECT * FROM grants WHERE patient_id=? AND doctor_id=? AND status='active' AND expires_at>? ORDER BY expires_at DESC", pid, did, now());

function loadProfile(pid) {
  const p = one('SELECT id,full_name,dob,blood_group,city,warnings,created_at FROM patients WHERE id=?', pid);
  return {
    patient: { ...p, age: age(p.dob) },
    conditions: all('SELECT * FROM conditions WHERE patient_id=? ORDER BY status, name', pid),
    allergies: all('SELECT * FROM allergies WHERE patient_id=? ORDER BY substance', pid),
    medications: all('SELECT * FROM medications WHERE patient_id=? ORDER BY active DESC, name', pid),
    contacts: all('SELECT * FROM contacts WHERE patient_id=? ORDER BY is_primary DESC, name', pid),
    documents: all('SELECT id,title,category,mime,size,created_at FROM documents WHERE patient_id=? ORDER BY created_at DESC', pid),
  };
}
const patientByToken = (token) => one('SELECT * FROM patients WHERE qr_hash=?', L.sha256(token));

// ---------- routes ----------
const routes = [];
const route = (method, re, roles, fn, opts = {}) => routes.push({ method, re, roles, fn, opts });
const AUTH = ['patient', 'caregiver', 'doctor', 'admin'], FAMILY = ['patient', 'caregiver'];

// -- public
route('GET', /^\/api\/healthz$/, false, () => ({ ok: true }));
route('GET', /^\/api\/demo-qr$/, false, () => ({ svg: qrSvg(`${cfg.baseUrl}/s/demo-not-a-real-token`) }));

route('POST', /^\/api\/register$/, false, async (ctx) => {
  limit(`reg:${ctx.ip}`, 10, 3600e3);
  const b = ctx.body;
  const role = E(b.role, ['patient', 'caregiver', 'doctor']);
  if (!role) throw bad();
  const email = EMAIL(b.email), name = S(b.name, 120, true), phone = PH(b.phone, false);
  if (typeof b.password !== 'string' || b.password.length < 10 || b.password.length > 200) throw bad('weak_password');
  if (b.password.toLowerCase() === email) throw bad('weak_password');
  const u = { email, name, phone, role, pw: await L.hashPw(b.password) };
  if (role === 'doctor') { u.license_no = S(b.license_no, 60, true); u.specialty = S(b.specialty, 80, true); u.facility = S(b.facility, 120); }
  let prof;
  if (role === 'patient') prof = { full_name: name, dob: D(b.dob), blood_group: E(b.blood_group, BLOOD), city: S(b.city, 80), warnings: null };
  if (role === 'patient' && !prof.dob) throw bad('missing');
  if (one('SELECT 1 FROM users WHERE email=?', email)) throw new HttpError(409, 'email_taken');
  const id = tx(() => { const uid = createUser(u); if (prof) createPatient(uid, prof, 'owner'); audit({ id: uid, role }, null, 'register', null, ctx.ip); return uid; });
  startSession(ctx.req, ctx.res, ctx.ip, id);
  return { ok: true };
});

route('POST', /^\/api\/login$/, false, async (ctx) => {
  limit(`login:${ctx.ip}`, 20, 15 * 60e3);
  const email = String(ctx.body.email || '').toLowerCase().trim(), pw = String(ctx.body.password || '');
  const u = one('SELECT * FROM users WHERE email=? AND disabled=0', email);
  const ok = await L.checkPw(pw, u ? u.pw : 's1$AAAAAAAAAAAAAAAAAAAAAA==$' + Buffer.alloc(64).toString('base64')); // constant-ish time for unknown emails
  if (u && u.locked_until && u.locked_until > now()) throw new HttpError(429, 'rate_limited');
  if (!u || !ok) {
    if (u) { const f = u.failed + 1; run('UPDATE users SET failed=?, locked_until=? WHERE id=?', f, f >= 5 ? new Date(Date.now() + 15 * 60e3).toISOString() : null, u.id); audit({ id: u.id, role: u.role }, null, 'login_failed', null, ctx.ip); }
    throw new HttpError(401, 'bad_credentials');
  }
  run('UPDATE users SET failed=0, locked_until=NULL WHERE id=?', u.id);
  startSession(ctx.req, ctx.res, ctx.ip, u.id);
  audit({ id: u.id, role: u.role }, null, 'login', null, ctx.ip);
  return { ok: true };
});

// -- session
route('GET', /^\/api\/me$/, false, (ctx) => ({ user: ctx.user || null, csrf: ctx.session?.csrf || null }));
route('POST', /^\/api\/logout$/, AUTH, (ctx) => { run('DELETE FROM sessions WHERE id=?', ctx.session.id); cookie(ctx.res, '', 0); return { ok: true }; });

// -- family: profiles
route('GET', /^\/api\/patients$/, FAMILY, (ctx) => ({
  patients: all(`SELECT p.id,p.full_name,p.dob,p.blood_group,m.relation,
    (SELECT COUNT(*) FROM grants g WHERE g.patient_id=p.id AND g.status='pending') pending,
    (SELECT COUNT(*) FROM conditions x WHERE x.patient_id=p.id) conditions, (SELECT COUNT(*) FROM allergies x WHERE x.patient_id=p.id) allergies,
    (SELECT COUNT(*) FROM medications x WHERE x.patient_id=p.id AND x.active=1) medications, (SELECT COUNT(*) FROM contacts x WHERE x.patient_id=p.id) contacts
    FROM patients p JOIN members m ON m.patient_id=p.id WHERE m.user_id=? ORDER BY p.full_name`, ctx.user.id),
}));
route('POST', /^\/api\/patients$/, FAMILY, (ctx) => {
  if (ctx.user.role === 'patient' && one('SELECT 1 FROM members WHERE user_id=?', ctx.user.id)) throw new HttpError(403, 'forbidden');
  const b = ctx.body;
  const p = { full_name: S(b.full_name, 120, true), dob: D(b.dob), blood_group: E(b.blood_group, BLOOD), city: S(b.city, 80), warnings: S(b.warnings, 600) };
  if (!p.dob) throw bad('missing');
  const id = tx(() => { const pid = createPatient(ctx.user.id, p, 'owner'); audit(ctx.user, pid, 'profile_created', null, ctx.ip); return pid; });
  return { id };
});
route('GET', /^\/api\/patients\/(\d+)$/, FAMILY, (ctx) => {
  const pid = +ctx.m[1]; const m = member(ctx, pid);
  return { ...loadProfile(pid), relation: m.relation };
});
route('PUT', /^\/api\/patients\/(\d+)$/, FAMILY, (ctx) => {
  const pid = +ctx.m[1]; member(ctx, pid); const b = ctx.body;
  const p = { full_name: S(b.full_name, 120, true), dob: D(b.dob), blood_group: E(b.blood_group, BLOOD), city: S(b.city, 80), warnings: S(b.warnings, 600) };
  if (!p.dob) throw bad('missing');
  run('UPDATE patients SET full_name=?,dob=?,blood_group=?,city=?,warnings=? WHERE id=?', p.full_name, p.dob, p.blood_group, p.city, p.warnings, pid);
  audit(ctx.user, pid, 'profile_updated', null, ctx.ip);
  return { ok: true };
});

// -- family: lists (conditions, allergies, medications, contacts)
route('POST', /^\/api\/patients\/(\d+)\/(conditions|allergies|medications|contacts)$/, FAMILY, (ctx) => {
  const pid = +ctx.m[1], k = KINDS[ctx.m[2]]; member(ctx, pid);
  const v = k.spec(ctx.body), cols = Object.keys(v);
  const r = run(`INSERT INTO ${k.table}(patient_id,${cols.join(',')}) VALUES(?,${cols.map(() => '?').join(',')})`, pid, ...cols.map((c) => v[c]));
  audit(ctx.user, pid, `add_${ctx.m[2]}`, { id: Number(r.lastInsertRowid) }, ctx.ip);
  return { id: Number(r.lastInsertRowid) };
});
route('PUT', /^\/api\/patients\/(\d+)\/(conditions|allergies|medications|contacts)\/(\d+)$/, FAMILY, (ctx) => {
  const pid = +ctx.m[1], k = KINDS[ctx.m[2]]; member(ctx, pid);
  const v = k.spec(ctx.body), cols = Object.keys(v);
  const r = run(`UPDATE ${k.table} SET ${cols.map((c) => `${c}=?`).join(',')} WHERE id=? AND patient_id=?`, ...cols.map((c) => v[c]), +ctx.m[3], pid);
  if (!r.changes) throw new HttpError(404, 'not_found');
  audit(ctx.user, pid, `edit_${ctx.m[2]}`, { id: +ctx.m[3] }, ctx.ip);
  return { ok: true };
});
route('DELETE', /^\/api\/patients\/(\d+)\/(conditions|allergies|medications|contacts)\/(\d+)$/, FAMILY, (ctx) => {
  const pid = +ctx.m[1], k = KINDS[ctx.m[2]]; member(ctx, pid);
  const r = run(`DELETE FROM ${k.table} WHERE id=? AND patient_id=?`, +ctx.m[3], pid);
  if (!r.changes) throw new HttpError(404, 'not_found');
  audit(ctx.user, pid, `delete_${ctx.m[2]}`, { id: +ctx.m[3] }, ctx.ip);
  return { ok: true };
});

// -- family: caregivers on a profile
route('GET', /^\/api\/patients\/(\d+)\/members$/, FAMILY, (ctx) => {
  const pid = +ctx.m[1]; member(ctx, pid);
  return { members: all('SELECT u.id,u.name,u.email,m.relation FROM members m JOIN users u ON u.id=m.user_id WHERE m.patient_id=? ORDER BY m.relation DESC, u.name', pid) };
});
route('POST', /^\/api\/patients\/(\d+)\/members$/, FAMILY, (ctx) => {
  const pid = +ctx.m[1]; if (member(ctx, pid).relation !== 'owner') throw new HttpError(403, 'forbidden');
  limit(`addmember:${ctx.user.id}`, 20, 3600e3);
  const u = one("SELECT id,role FROM users WHERE email=? AND role IN('patient','caregiver') AND disabled=0", EMAIL(ctx.body.email));
  if (!u) throw new HttpError(404, 'user_not_found');
  if (u.role === 'patient') throw new HttpError(400, 'must_be_caregiver');
  run("INSERT OR IGNORE INTO members(patient_id,user_id,relation) VALUES(?,?,'caregiver')", pid, u.id);
  audit(ctx.user, pid, 'caregiver_added', { user: u.id }, ctx.ip);
  return { ok: true };
});
route('DELETE', /^\/api\/patients\/(\d+)\/members\/(\d+)$/, FAMILY, (ctx) => {
  const pid = +ctx.m[1]; if (member(ctx, pid).relation !== 'owner') throw new HttpError(403, 'forbidden');
  if (+ctx.m[2] === ctx.user.id) throw bad();
  run('DELETE FROM members WHERE patient_id=? AND user_id=?', pid, +ctx.m[2]);
  audit(ctx.user, pid, 'caregiver_removed', { user: +ctx.m[2] }, ctx.ip);
  return { ok: true };
});

// -- family: QR
route('GET', /^\/api\/patients\/(\d+)\/qr$/, FAMILY, (ctx) => {
  const pid = +ctx.m[1]; member(ctx, pid);
  const p = one('SELECT * FROM patients WHERE id=?', pid);
  const url = `${cfg.baseUrl}/s/${qrToken(p)}`;
  return { url, svg: qrSvg(url), rotated_at: p.qr_rotated_at, name: p.full_name, blood_group: p.blood_group, phone: one('SELECT phone FROM contacts WHERE patient_id=? ORDER BY is_primary DESC, id LIMIT 1', pid)?.phone || null };
});
route('POST', /^\/api\/patients\/(\d+)\/qr\/rotate$/, FAMILY, (ctx) => {
  const pid = +ctx.m[1]; member(ctx, pid);
  rotateQr(pid);
  audit(ctx.user, pid, 'qr_rotated', null, ctx.ip);
  return { ok: true };
});

// -- family: access requests, grants, history
route('GET', /^\/api\/patients\/(\d+)\/grants$/, FAMILY, (ctx) => {
  const pid = +ctx.m[1]; member(ctx, pid);
  return { grants: all(`SELECT g.id,g.status,g.requested_at,g.decided_at,g.expires_at,u.name doctor_name,u.specialty,u.facility,u.license_no
    FROM grants g JOIN users u ON u.id=g.doctor_id WHERE g.patient_id=? ORDER BY g.requested_at DESC LIMIT 100`, pid) };
});
route('POST', /^\/api\/patients\/(\d+)\/grants\/(\d+)$/, FAMILY, (ctx) => {
  const pid = +ctx.m[1], gid = +ctx.m[2]; member(ctx, pid);
  const g = one('SELECT * FROM grants WHERE id=? AND patient_id=?', gid, pid);
  if (!g) throw new HttpError(404, 'not_found');
  const d = E(ctx.body.decision, ['approve', 'deny', 'revoke']);
  if (!d) throw bad();
  if (d === 'approve' && g.status === 'pending') {
    const hours = E(String(ctx.body.hours || 24), ['24', '168', '720']) || '24';
    run("UPDATE grants SET status='active',decided_at=?,expires_at=? WHERE id=?", now(), new Date(Date.now() + Number(hours) * 3600e3).toISOString(), gid);
  } else if (d === 'deny' && g.status === 'pending') run("UPDATE grants SET status='denied',decided_at=? WHERE id=?", now(), gid);
  else if (d === 'revoke' && g.status === 'active') run("UPDATE grants SET status='revoked',decided_at=? WHERE id=?", now(), gid);
  else throw bad('invalid_state');
  audit(ctx.user, pid, `grant_${d}`, { doctor: g.doctor_id }, ctx.ip);
  return { ok: true };
});
route('GET', /^\/api\/patients\/(\d+)\/access-log$/, FAMILY, (ctx) => {
  const pid = +ctx.m[1]; member(ctx, pid);
  return { log: all(`SELECT a.id,a.ts,a.action,a.detail,a.actor_role,u.name actor_name,u.specialty,u.facility
    FROM audit a LEFT JOIN users u ON u.id=a.actor_id WHERE a.patient_id=? ORDER BY a.id DESC LIMIT 200`, pid) };
});

// -- documents (PDF / PNG / JPEG), encrypted at rest
const MAX_UPLOAD = 10 * 1024 * 1024;
const sniff = (b) => (b.subarray(0, 5).toString('latin1') === '%PDF-' ? 'application/pdf' : b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) ? 'image/png' : b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff ? 'image/jpeg' : null);
const DOC_CATS = ['xray', 'mri', 'ct', 'ultrasound', 'lab', 'prescription', 'discharge', 'report', 'vaccination', 'other'];
route('POST', /^\/api\/patients\/(\d+)\/documents$/, FAMILY, (ctx) => {
  const pid = +ctx.m[1]; member(ctx, pid);
  limit(`upload:${ctx.user.id}`, 30, 3600e3);
  const buf = ctx.raw;
  if (!buf.length) throw bad('missing');
  const mime = sniff(buf); // trust the bytes, never the client-declared type or filename
  if (!mime) throw bad('bad_file_type');
  const title = S(decodeURIComponent(String(ctx.req.headers['x-title'] || '')), 120, true);
  const category = E(String(ctx.req.headers['x-category'] || 'other'), DOC_CATS, 'other');
  const file = crypto.randomBytes(16).toString('hex') + '.bin';
  fs.writeFileSync(path.join(cfg.dataDir, 'uploads', file), L.encBuf(buf, DATA_KEY), { mode: 0o600 });
  const r = run('INSERT INTO documents(patient_id,title,category,mime,size,file,uploaded_by,created_at) VALUES(?,?,?,?,?,?,?,?)', pid, title, category, mime, buf.length, file, ctx.user.id, now());
  audit(ctx.user, pid, 'document_uploaded', { id: Number(r.lastInsertRowid) }, ctx.ip);
  return { id: Number(r.lastInsertRowid) };
}, { upload: true });
route('DELETE', /^\/api\/patients\/(\d+)\/documents\/(\d+)$/, FAMILY, (ctx) => {
  const pid = +ctx.m[1]; member(ctx, pid);
  const d = one('SELECT * FROM documents WHERE id=? AND patient_id=?', +ctx.m[2], pid);
  if (!d) throw new HttpError(404, 'not_found');
  run('DELETE FROM documents WHERE id=?', d.id);
  fs.rmSync(path.join(cfg.dataDir, 'uploads', d.file), { force: true });
  audit(ctx.user, pid, 'document_deleted', { id: d.id }, ctx.ip);
  return { ok: true };
});
route('GET', /^\/api\/documents\/(\d+)\/file$/, AUTH, (ctx) => {
  const d = one('SELECT * FROM documents WHERE id=?', +ctx.m[1]);
  if (!d) throw new HttpError(404, 'not_found');
  if (ctx.user.role === 'doctor') { needVerifiedDoctor(ctx); if (!activeGrant(d.patient_id, ctx.user.id)) throw new HttpError(403, 'no_access'); }
  else member(ctx, d.patient_id); // admins cannot open medical documents
  const data = L.decBuf(fs.readFileSync(path.join(cfg.dataDir, 'uploads', d.file)), DATA_KEY);
  audit(ctx.user, d.patient_id, 'document_viewed', { id: d.id }, ctx.ip);
  const inline = d.mime !== 'application/pdf'; // PDFs are downloaded, never rendered inside our origin
  return { raw: data, headers: { 'Content-Type': d.mime, 'Content-Disposition': `${inline ? 'inline' : 'attachment'}; filename="document-${d.id}.${d.mime === 'application/pdf' ? 'pdf' : d.mime === 'image/png' ? 'png' : 'jpg'}"`, 'Content-Security-Policy': "default-src 'none'; sandbox" } };
});

// -- doctors: scan, request, emergency, record
route('GET', /^\/api\/scan\/([\w-]{20,64})$/, ['doctor'], (ctx) => {
  needVerifiedDoctor(ctx);
  limit(`scan:${ctx.user.id}`, 60, 60e3);
  const p = patientByToken(ctx.m[1]);
  if (!p) { audit(ctx.user, null, 'scan_invalid', null, ctx.ip); throw new HttpError(404, 'invalid_qr'); }
  const g = one("SELECT * FROM grants WHERE patient_id=? AND doctor_id=? AND status IN('pending','active') ORDER BY id DESC", p.id, ctx.user.id);
  const access = g?.status === 'active' && g.expires_at > now() ? 'granted' : g?.status === 'pending' ? 'pending' : 'none';
  audit(ctx.user, p.id, 'scan', { access }, ctx.ip);
  return { patient: { id: p.id, display: mask(p.full_name) }, access };
});
route('POST', /^\/api\/scan\/([\w-]{20,64})\/request$/, ['doctor'], (ctx) => {
  needVerifiedDoctor(ctx);
  const p = patientByToken(ctx.m[1]); if (!p) throw new HttpError(404, 'invalid_qr');
  limit(`req:${ctx.user.id}`, 30, 3600e3);
  if (activeGrant(p.id, ctx.user.id)) return { access: 'granted' };
  if (!one("SELECT 1 FROM grants WHERE patient_id=? AND doctor_id=? AND status='pending'", p.id, ctx.user.id)) {
    run("INSERT INTO grants(patient_id,doctor_id,status,requested_at) VALUES(?,?,'pending',?)", p.id, ctx.user.id, now());
    audit(ctx.user, p.id, 'access_requested', null, ctx.ip);
  }
  return { access: 'pending' };
});
route('POST', /^\/api\/scan\/([\w-]{20,64})\/emergency$/, ['doctor'], (ctx) => {
  needVerifiedDoctor(ctx);
  limit(`emg:${ctx.user.id}`, 20, 24 * 3600e3);
  const p = patientByToken(ctx.m[1]); if (!p) throw new HttpError(404, 'invalid_qr');
  const reason = E(ctx.body.reason, EMERGENCY_REASONS), why = S(ctx.body.justification, 500, true);
  if (!reason || why.length < 10 || ctx.body.confirm !== true) throw bad('justification_required');
  audit(ctx.user, p.id, 'emergency_access', { reason, justification: why }, ctx.ip);
  // Minimal data set only: no documents, no history notes, no lab data.
  const f = loadProfile(p.id);
  return {
    emergency: true,
    patient: { full_name: f.patient.full_name, age: f.patient.age, blood_group: f.patient.blood_group, warnings: f.patient.warnings },
    allergies: f.allergies.map(({ substance, reaction, severity }) => ({ substance, reaction, severity })),
    conditions: f.conditions.filter((c) => c.status === 'active').map((c) => ({ name: c.name })),
    medications: f.medications.filter((m) => m.active).map(({ name, dose, frequency, route }) => ({ name, dose, frequency, route })),
    contacts: f.contacts.map(({ name, relation, phone }) => ({ name, relation, phone })),
  };
});
route('GET', /^\/api\/doctor\/grants$/, ['doctor'], (ctx) => {
  needVerifiedDoctor(ctx);
  const rows = all(`SELECT g.id,g.patient_id,g.status,g.requested_at,g.expires_at,p.full_name FROM grants g JOIN patients p ON p.id=g.patient_id
    WHERE g.doctor_id=? ORDER BY g.requested_at DESC LIMIT 50`, ctx.user.id);
  return { grants: rows.map((r) => { const live = r.status === 'active' && r.expires_at > now(); return { ...r, status: r.status === 'active' && !live ? 'expired' : r.status, full_name: live ? r.full_name : mask(r.full_name) }; }) };
});
route('GET', /^\/api\/doctor\/patients\/(\d+)\/record$/, ['doctor'], (ctx) => {
  needVerifiedDoctor(ctx);
  const pid = +ctx.m[1], g = activeGrant(pid, ctx.user.id);
  if (!g) throw new HttpError(403, 'no_access');
  audit(ctx.user, pid, 'view_record', null, ctx.ip);
  return { ...loadProfile(pid), expires_at: g.expires_at };
});

// -- admin (admins manage accounts; they cannot read medical data)
route('GET', /^\/api\/admin\/stats$/, ['admin'], () => ({
  users: all('SELECT role,COUNT(*) n FROM users GROUP BY role'),
  patients: one('SELECT COUNT(*) n FROM patients').n,
  pending_doctors: one("SELECT COUNT(*) n FROM users WHERE role='doctor' AND doc_status='pending'").n,
  emergencies_30d: one("SELECT COUNT(*) n FROM audit WHERE action='emergency_access' AND ts>?", new Date(Date.now() - 30 * 86400e3).toISOString()).n,
}));
route('GET', /^\/api\/admin\/doctors$/, ['admin'], (ctx) => {
  const st = E(ctx.url.searchParams.get('status'), ['pending', 'approved', 'rejected'], 'pending');
  return { doctors: all('SELECT id,name,email,phone,license_no,specialty,facility,doc_status,doc_note,created_at FROM users WHERE role=? AND doc_status=? ORDER BY created_at DESC LIMIT 200', 'doctor', st) };
});
route('POST', /^\/api\/admin\/doctors\/(\d+)$/, ['admin'], (ctx) => {
  const status = E(ctx.body.status, ['approved', 'rejected']); if (!status) throw bad();
  const note = S(ctx.body.note, 300);
  const r = run("UPDATE users SET doc_status=?, doc_note=? WHERE id=? AND role='doctor'", status, note, +ctx.m[1]);
  if (!r.changes) throw new HttpError(404, 'not_found');
  audit(ctx.user, null, `doctor_${status}`, { doctor: +ctx.m[1], note }, ctx.ip);
  return { ok: true };
});
route('GET', /^\/api\/admin\/audit$/, ['admin'], () => ({
  log: all(`SELECT a.id,a.ts,a.action,a.actor_role,a.patient_id,a.detail,u.name actor_name FROM audit a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.id DESC LIMIT 200`),
  chain: verifyAudit(),
}));

// ---------- request pipeline ----------
function send(res, status, body, headers = {}) {
  const isBuf = Buffer.isBuffer(body);
  res.writeHead(status, { 'Content-Type': isBuf ? 'application/octet-stream' : 'application/json; charset=utf-8', ...headers });
  res.end(isBuf ? body : JSON.stringify(body));
}
const clientIp = (req) => (cfg.trustProxy ? String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() : '') || req.socket.remoteAddress || '';

function secHeaders(res) {
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer'); // the QR token lives in the URL: never leak it via Referer
  res.setHeader('Permissions-Policy', 'camera=(self), microphone=(), geolocation=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  if (cfg.secure) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
}

async function api(req, res, url, ip) {
  const sess = getSession(req);
  const ctx = { req, res, url, ip, session: sess?.s, user: sess?.user, m: null, body: {}, raw: null };
  for (const r of routes) {
    if (r.method !== req.method) continue;
    const m = r.re.exec(url.pathname);
    if (!m) continue;
    ctx.m = m;
    if (r.roles && (!ctx.user || !r.roles.includes(ctx.user.role))) throw new HttpError(ctx.user ? 403 : 401, ctx.user ? 'forbidden' : 'auth_required');
    if (!['GET', 'HEAD'].includes(req.method) && ctx.user && req.headers['x-csrf'] !== ctx.session.csrf) throw new HttpError(403, 'csrf');
    if (r.opts.upload) ctx.raw = await readBody(req, MAX_UPLOAD);
    else if (!['GET', 'HEAD'].includes(req.method)) {
      const raw = await readBody(req, 100 * 1024);
      if (raw.length) { try { ctx.body = JSON.parse(raw.toString('utf8')); } catch { throw bad('bad_json'); } }
      if (ctx.body === null || typeof ctx.body !== 'object') throw bad('bad_json');
    }
    const out = await r.fn(ctx);
    if (out && out.raw) return send(res, 200, out.raw, { 'Cache-Control': 'no-store', ...out.headers });
    return send(res, 200, out, { 'Cache-Control': 'no-store' });
  }
  throw new HttpError(404, 'not_found');
}

function serveStatic(req, res, url) {
  if (!['GET', 'HEAD'].includes(req.method)) return send(res, 405, { error: 'method' });
  let rel = decodeURIComponent(url.pathname);
  let file = path.join(cfg.publicDir, rel === '/' ? 'index.html' : rel);
  if (!file.startsWith(cfg.publicDir + path.sep) && file !== cfg.publicDir) return send(res, 403, { error: 'forbidden' });
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    if (path.extname(rel)) return send(res, 404, { error: 'not_found' });
    file = path.join(cfg.publicDir, 'index.html'); // single-page app routes
  }
  const ext = path.extname(file);
  res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=300' });
  res.end(req.method === 'HEAD' ? undefined : fs.readFileSync(file));
}

const server = http.createServer(async (req, res) => {
  secHeaders(res);
  try {
    const url = new URL(req.url, 'http://local');
    if (url.pathname.startsWith('/api/')) await api(req, res, url, clientIp(req));
    else serveStatic(req, res, url);
  } catch (e) {
    if (!(e instanceof HttpError)) console.error(e);
    if (!res.headersSent) send(res, e.status || 500, { error: e instanceof HttpError ? e.code : 'server' }, { 'Cache-Control': 'no-store' });
    else res.end();
  }
});

// First run: make sure an administrator exists.
if (!one("SELECT 1 FROM users WHERE role='admin'")) {
  const email = process.env.ADMIN_EMAIL || 'admin@hawiya.local';
  const pw = process.env.ADMIN_PASSWORD || L.rand(12);
  createUser({ email, pw: await L.hashPw(pw), role: 'admin', name: 'Administrator' });
  console.log(`\n  First-run administrator created\n    email:    ${email}\n    password: ${process.env.ADMIN_PASSWORD ? '(from ADMIN_PASSWORD)' : pw}\n  Change or store this password now; it is not shown again.\n`);
}
if (path.resolve(process.argv[1] || '') === fileURLToPath(import.meta.url)) {
  server.listen(cfg.port, () => console.log(`Hawiya running at ${cfg.baseUrl}  (port ${cfg.port})`));
}
export { server };
