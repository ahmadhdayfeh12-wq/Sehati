import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';

const root = path.resolve(import.meta.dirname, '..');
const port = Number(process.env.PORT) || 3000;

export const cfg = {
  port,
  baseUrl: (process.env.BASE_URL || `http://localhost:${port}`).replace(/\/$/, ''),
  dataDir: path.resolve(process.env.DATA_DIR || path.join(root, 'data')),
  publicDir: path.join(root, 'public'),
  trustProxy: process.env.TRUST_PROXY === '1',
};
cfg.secure = cfg.baseUrl.startsWith('https://');
cfg.production = process.env.NODE_ENV === 'production';
if (cfg.production) {
  // Fail closed: never run production with generated-on-disk keys, plain HTTP, or a default admin.
  const problems = [];
  if (!process.env.DATA_KEY) problems.push('DATA_KEY (64 hex chars) is required');
  if (!cfg.secure) problems.push('BASE_URL must be an https:// URL');
  if (!process.env.ADMIN_EMAIL || !process.env.ADMIN_PASSWORD) problems.push('ADMIN_EMAIL and ADMIN_PASSWORD are required for the first start');
  if (process.env.ADMIN_PASSWORD && process.env.ADMIN_PASSWORD.length < 12) problems.push('ADMIN_PASSWORD must be at least 12 characters');
  if (problems.length) { console.error('Refusing to start in production:\n - ' + problems.join('\n - ')); process.exit(1); }
}
fs.mkdirSync(path.join(cfg.dataDir, 'uploads'), { recursive: true, mode: 0o700 });

// 32-byte key used for AES-256-GCM encryption of uploaded files and stored QR tokens.
// Production: set DATA_KEY (64 hex chars) from a secret manager / KMS, never from a file next to the data.
function loadKey() {
  if (process.env.DATA_KEY) {
    const k = Buffer.from(process.env.DATA_KEY, 'hex');
    if (k.length !== 32) throw new Error('DATA_KEY must be 64 hex characters');
    return k;
  }
  const f = path.join(cfg.dataDir, 'data.key');
  if (fs.existsSync(f)) return Buffer.from(fs.readFileSync(f, 'utf8').trim(), 'hex');
  const k = crypto.randomBytes(32);
  fs.writeFileSync(f, k.toString('hex'), { mode: 0o600 });
  return k;
}
export const DATA_KEY = loadKey();
