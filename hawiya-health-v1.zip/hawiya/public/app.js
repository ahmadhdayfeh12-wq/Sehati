import { DICT } from './i18n.js';
import { icon } from './icons.js';
import { defs, logo, heroArt, stepArt, authArt } from './art.js';

// ---------- tiny toolkit ----------
const $ = (s, r = document) => r.querySelector(s);
class Raw { constructor(s) { this.s = s; } }
const raw = (s) => new Raw(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const val = (v) => (v instanceof Raw ? v.s : Array.isArray(v) ? v.map(val).join('') : esc(v));
// Every interpolated value is escaped unless it is already trusted markup from h``.
const h = (strs, ...vals) => new Raw(strs.reduce((a, s, i) => a + s + (i < vals.length ? val(vals[i]) : ''), ''));

const S = { user: null, csrf: null, lang: localStorage.getItem('lang') || ((navigator.language || '').toLowerCase().startsWith('ar') ? 'ar' : 'en') };
const t = (k, v) => String(DICT[S.lang][k] ?? DICT.en[k] ?? k).replace(/\{(\w+)\}/g, (_, n) => v?.[n] ?? '');
const setLang = (l) => { S.lang = l; localStorage.setItem('lang', l); document.documentElement.lang = l; document.documentElement.dir = l === 'ar' ? 'rtl' : 'ltr'; };
setLang(S.lang);
if (localStorage.getItem('big') === '1') document.documentElement.classList.add('big');

const fmt = (iso, time = true) => iso ? new Intl.DateTimeFormat(S.lang === 'ar' ? 'ar-u-nu-latn' : 'en-GB', { dateStyle: 'medium', ...(time ? { timeStyle: 'short' } : {}) }).format(new Date(iso)) : '';
// Isolate each fragment so mixed Arabic/Latin text keeps its own direction.
const dots = (arr) => raw(arr.filter(Boolean).map((x) => `<bdi>${esc(x)}</bdi>`).join(' · '));
const BLOOD = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

async function api(path, { method = 'GET', body, rawBody, headers = {} } = {}) {
  const o = { method, headers: { ...headers }, credentials: 'same-origin' };
  if (S.csrf) o.headers['X-CSRF'] = S.csrf;
  if (rawBody) o.body = rawBody;
  else if (body !== undefined) { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(body); }
  const r = await fetch(path, o);
  let data = null; try { data = await r.json(); } catch { /* not json */ }
  if (!r.ok) { const e = new Error(data?.error || 'server'); e.status = r.status; e.code = data?.error || 'server'; throw e; }
  return data;
}
async function loadMe() { const r = await api('/api/me'); S.user = r.user; S.csrf = r.csrf; }

let toastTimer;
function toast(msg, isErr) {
  const el = $('#toast'); el.innerHTML = ''; const d = document.createElement('div'); d.textContent = msg; if (isErr) d.className = 'err'; el.append(d);
  clearTimeout(toastTimer); toastTimer = setTimeout(() => (el.innerHTML = ''), 4500);
}
const fail = (e) => toast(DICT[S.lang]['err.' + e.code] || t('err.server'), true);
const roleHome = (r) => (r === 'doctor' ? '/doctor' : r === 'admin' ? '/admin' : '/app');
const safeNext = (n) => (n && n.startsWith('/') && !n.startsWith('//') ? n : null);

// ---------- design helpers ----------
const ic = (n, cls = '') => raw(icon(n, cls));
const LOGO = raw(logo());
const initials = (n) => String(n || '?').trim().split(/\s+/).slice(0, 2).map((w) => [...w][0]).join('').toUpperCase();
const av = (name, id = 0, cls = '') => h`<span class="av v${Number(id) % 4} ${cls}" aria-hidden="true">${initials(name)}</span>`;
const chip = (txt, tone = '', icn) => h`<span class="chip ${tone}">${icn ? ic(icn) : ''}${txt}</span>`;
const readiness = (c) => Math.round(([c.allergies, c.conditions, c.medications, c.contacts].filter((n) => n > 0).length / 4) * 100);
const ring = (pct) => h`<div class="ring" role="img" aria-label="${pct}%"><svg viewBox="0 0 56 56" aria-hidden="true"><circle class="tr" cx="28" cy="28" r="24" fill="none" stroke-width="5"/><circle class="pr" cx="28" cy="28" r="24" fill="none" stroke-width="5" stroke-linecap="round" stroke-dasharray="${(pct * 1.508).toFixed(1)} 150.8"/></svg><b>${pct}%</b></div>`;
const roleHomeLabel = (r) => (r === 'doctor' ? t('nav.doctor') : r === 'admin' ? t('nav.admin') : t('nav.family'));

// ---------- shells ----------
function navModel() {
  const u = S.user, q = new URLSearchParams(location.search), p = location.pathname;
  if (u.role === 'doctor') return [{ items: [{ href: '/doctor', i: 'stethoscope', l: t('nav.doctor'), on: p.startsWith('/doctor') || p.startsWith('/s/') }] }];
  if (u.role === 'admin') {
    const tab = q.get('tab') || 'doctors';
    return [{ items: [['doctors', 'shield-check', t('adm.doctors')], ['stats', 'chart', t('adm.stats')], ['audit', 'list', t('adm.audit')]].map(([k, i, l]) => ({ href: `/admin?tab=${k}`, i, l, on: p === '/admin' && tab === k })) }];
  }
  return [{ items: [{ href: '/app', i: 'home', l: t('nav.family'), on: p === '/app' }] },
    ...(S.people?.length ? [{ label: t('nav.people'), items: S.people.map((x) => ({ href: `/app/p/${x.id}`, av: x, l: x.full_name, on: p === `/app/p/${x.id}` || p === `/card/${x.id}` })) }] : [])];
}
function appShell(content) {
  const u = S.user, groups = navModel(), big = document.documentElement.classList.contains('big');
  const link = (it) => h`<a class="nav-i" data-link href="${it.href}" ${it.on ? raw('aria-current="page"') : ''}>${it.av ? av(it.av.full_name, it.av.id) : ic(it.i)}<span>${it.l}</span></a>`;
  const flat = groups.flatMap((g) => g.items);
  return h`<div class="app"><aside class="side noprint"><a class="brand" data-link href="${roleHome(u.role)}">${LOGO}<span>${t('brand')}</span></a>
      ${groups.map((g) => h`${g.label ? h`<div class="grp">${g.label}</div>` : ''}${g.items.map(link)}`)}
      <div class="side-foot"><div class="tools"><button class="tool" data-act="lang">${ic('globe')}${S.lang === 'ar' ? 'English' : 'العربية'}</button><button class="tool" data-act="big" aria-label="${t('bigtext')}" aria-pressed="${big}">Aa</button></div>
      <div class="me">${av(u.name, u.id)}<div class="grow"><b>${u.name}</b><small>${roleHomeLabel(u.role)}</small></div><button class="ibtn" data-act="logout" aria-label="${t('nav.logout')}" title="${t('nav.logout')}">${ic('logout')}</button></div></div></aside>
    <div><header class="mbar noprint"><a class="brand" data-link href="${roleHome(u.role)}">${LOGO}<span>${t('brand')}</span></a><span class="sp"></span>
      <button class="ibtn" data-act="lang" aria-label="${t('lang.switch')}">${ic('globe')}</button><button class="ibtn" data-act="big" aria-label="${t('bigtext')}" aria-pressed="${big}">Aa</button><button class="ibtn" data-act="logout" aria-label="${t('nav.logout')}">${ic('logout')}</button></header>
      ${flat.length > 1 ? h`<nav class="mnav noprint" aria-label="Main">${flat.map((it) => h`<a data-link href="${it.href}" ${it.on ? raw('aria-current="page"') : ''}>${it.av ? av(it.av.full_name, it.av.id, 'sm') : ic(it.i)}${it.l}</a>`)}</nav>` : ''}
      <main id="main" tabindex="-1" class="content">${content}<p class="appfoot">${t('footer')}</p></main></div></div>`;
}
function pubShell(content, { nav = true } = {}) {
  const u = S.user;
  return h`${nav ? h`<header class="pubnav"><div class="in"><a class="brand" data-link href="/">${LOGO}<span>${t('brand')}</span></a><span class="sp"></span>
      <button class="plink" data-act="lang">${S.lang === 'ar' ? 'English' : 'العربية'}</button>
      ${u ? h`<a class="btn sm light" data-link href="${roleHome(u.role)}">${t('nav.dashboard')}</a>` : h`<a class="plink" data-link href="/login">${t('nav.login')}</a><a class="btn sm light" data-link href="/register?role=caregiver">${t('nav.register')}</a>`}</div></header>` : ''}
    <main id="main" tabindex="-1" class="pubmain">${content}</main>
    ${nav ? h`<footer class="pubfoot"><div class="in"><div><a class="brand" data-link href="/">${LOGO}<span>${t('brand')}</span></a><p>${t('foot.tag')}</p></div>
      <div><a data-link href="/register?role=caregiver">${t('role.caregiver')}</a><a data-link href="/register?role=doctor">${t('role.doctor')}</a><a data-link href="/login">${t('nav.login')}</a></div><p class="legal">${t('footer')}</p></div></footer>` : ''}`;
}
function page(content, opts = {}) {
  stopCam();
  const pub = opts.pub || !S.user;
  $('#app').innerHTML = defs + (pub ? pubShell(content, opts) : appShell(content)).s;
  document.title = t('brand') + ' · ' + t('tagline.short');
  window.scrollTo(0, 0);
  $('.tabs [aria-current]')?.scrollIntoView({ inline: 'center', block: 'nearest' });
  const els = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) { const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: 0.12 }); els.forEach((el) => io.observe(el)); }
  else els.forEach((el) => el.classList.add('in'));
}

// ---------- landing ----------
async function landing() {
  const demo = await api('/api/demo-qr').catch(() => ({ svg: '' }));
  const step = (k) => h`<li class="step reveal"><div class="art">${raw(k === 2 ? stepArt[2](parseDemo(demo.svg)) : stepArt[k])}</div><span class="n">${k}</span><h3>${t(`how.${k}.t`)}</h3><p>${t(`how.${k}.d`)}</p></li>`;
  const promise = (k, i) => h`<div class="pm reveal"><span class="ico-chip teal">${ic(i)}</span><h3>${t(`pr.${k}.t`)}</h3><p>${t(`pr.${k}.d`)}</p></div>`;
  page(h`<section class="hero"><div class="wrap">
      <div class="rise"><span class="badge-top"><i>${ic('sparkle')}</i>${t('land.badge')}</span><h1>${t('hero.title')}</h1><p class="lead">${t('hero.sub')}</p>
        <div class="row"><a class="btn teal lg" data-link href="/register?role=caregiver">${t('hero.cta1')}<span class="flip">${ic('arrow')}</span></a><a class="btn line-light lg" data-link href="/register?role=doctor">${ic('stethoscope')}${t('hero.cta2')}</a></div>
        <div class="trust"><span>${ic('lock')}${t('pr.4.t')}</span><span>${ic('shield-check')}${t('pr.2.t')}</span><span>${ic('globe')}${t('trust.3')}</span></div></div>
      <div class="hero-art">${raw(heroArt(demo.svg))}
        <div class="fchip a"><span class="ico-chip teal">${ic('shield-check')}</span><div>${t('fl.a.t')}<small>${t('fl.a.d')}</small></div></div>
        <div class="fchip b"><span class="ico-chip">${ic('eye')}</span><div>${t('a.scan')}<small>${t('fl.now')}</small></div></div>
        <div class="fchip c"><span class="ico-chip red">${ic('alert')}</span><div>${t('card.sample.allergy')}<small>${t('fl.c.d')}</small></div></div></div></div></section>
    <section class="sec"><div class="wrap"><div class="sec-h c reveal"><span class="kicker">${t('how.k')}</span><h2>${t('how.title')}</h2><p>${t('how.sub')}</p></div><ol class="steps list">${step(1)}${step(2)}${step(3)}</ol></div></section>
    <section class="em-sec"><div class="wrap"><div class="reveal"><span class="kicker">${t('em.k')}</span><h2>${t('em.title')}</h2><p>${t('em.d')}</p>
      <ul class="tick">${[1, 2, 3].map((n) => h`<li>${ic('check')}<span>${t('em.' + n)}</span></li>`)}</ul></div>
      <div class="screen reveal"><header>${ic('alert')}${t('emg.banner')}</header><div class="bd"><div><h4>${t('f.full_name')}</h4><b>${t('card.sample.name')}</b></div>
        <div><h4>${t('f.blood_group')}</h4><div class="blood ltr">O+</div></div><div><h4>${t('tab.allergies')}</h4><div class="chips">${chip(t('card.sample.allergy'), 'red')}</div></div>
        <div><h4>${t('tab.medications')}</h4><div class="chips">${chip('Metformin 500 mg', 'teal')}${chip('Warfarin 3 mg', 'teal')}</div></div>
        <div><h4>${t('tab.contacts')}</h4><div class="chips">${chip(t('em.contact'), 'green', 'phone')}</div></div></div></div></div></section>
    <section class="sec"><div class="wrap"><div class="sec-h reveal"><span class="kicker">${t('ft.k')}</span><h2>${t('ft.title')}</h2><p>${t('ft.sub')}</p></div><div class="bento">
      <div class="bt navy w4 reveal"><span class="ico-chip navy">${ic('list')}</span><h3>${t('ft.audit.t')}</h3><p>${t('ft.audit.d')}</p>
        <div class="mini-log"><div>${ic('eye')}${t('a.scan')}<time class="ltr">09:41</time></div><div>${ic('check')}${t('a.grant_approve')}<time class="ltr">09:43</time></div><div class="em">${ic('alert')}${t('a.emergency_access')}<time class="ltr">02:17</time></div></div></div>
      <div class="bt teal w2 reveal"><span class="ico-chip teal">${ic('globe')}</span><h3>${t('ft.lang.t')}</h3><p>${t('ft.lang.d')}</p></div>
      <div class="bt w2 reveal"><span class="ico-chip teal">${ic('pill')}</span><h3>${t('ft.meds.t')}</h3><p>${t('ft.meds.d')}</p></div>
      <div class="bt w2 reveal"><span class="ico-chip">${ic('file')}</span><h3>${t('ft.docs.t')}</h3><p>${t('ft.docs.d')}</p></div>
      <div class="bt w2 reveal"><span class="ico-chip amber">${ic('users')}</span><h3>${t('ft.fam.t')}</h3><p>${t('ft.fam.d')}</p></div></div></div></section>
    <section class="sec tint"><div class="wrap"><div class="sec-h c reveal"><span class="kicker">${t('pr.k')}</span><h2>${t('pr.title')}</h2></div><div class="promises">${promise(1, 'qr')}${promise(2, 'shield-check')}${promise(3, 'eye')}${promise(4, 'key')}</div></div></section>
    <section class="sec"><div class="wrap"><div class="cta reveal"><h2>${t('cta.title')}</h2><p>${t('cta.sub')}</p>      <p><a class="btn teal lg" data-link href="/register?role=caregiver">${t('hero.cta1')}</a> <a class="btn line-light lg" data-link href="/register?role=doctor">${t('hero.cta2')}</a></p></div></div></section>`);
}
const parseDemo = (svg) => { const vb = /viewBox="([^"]+)"/.exec(svg || ''), d = /<path d="([^"]+)"/.exec(svg || ''); return vb && d ? { vb: vb[1], d: d[1] } : null; };

// ---------- auth ----------
function authView(mode) {
  const q = new URLSearchParams(location.search);
  if (S.user) return go(safeNext(q.get('next')) || roleHome(S.user.role), true);
  const field = (n, type, req = true, extra = '') => h`<div class="field"><label for="a-${n}">${t('f.' + n)}</label><input id="a-${n}" name="${n}" type="${type}" ${req ? 'required' : ''} ${raw(extra)}></div>`;
  const side = h`<aside class="auth-side"><a class="brand" data-link href="/">${LOGO}<span>${t('brand')}</span></a>${raw(authArt)}<h2>${t('auth.side.t')}</h2>
    <ul>${[['lock', 'pr.1.t'], ['shield-check', 'pr.2.t'], ['eye', 'pr.3.t']].map(([i, k]) => h`<li>${ic(i)}${t(k)}</li>`)}</ul></aside>`;
  let body;
  if (mode === 'login') {
    body = h`<h1>${t('login.title')}</h1><p class="muted">${t('login.sub')}</p><form data-form="login" data-next="${q.get('next') || ''}">
      ${field('email', 'email', true, 'autocomplete="username"')}${field('password', 'password', true, 'autocomplete="current-password"')}
      <button class="btn lg block" type="submit">${t('nav.login')}</button></form><p class="muted center" >${t('login.new')} <a data-link href="/register">${t('nav.register')}</a></p>`;
  } else {
    const role = ['caregiver', 'patient', 'doctor'].includes(q.get('role')) ? q.get('role') : 'caregiver';
    const icons = { caregiver: 'users', patient: 'user', doctor: 'stethoscope' };
    const nx = q.get('next') ? '&next=' + encodeURIComponent(q.get('next')) : '';
    body = h`<h1>${t('reg.title')}</h1><div class="seg" role="tablist">${['caregiver', 'patient', 'doctor'].map((r) => h`<a data-link href="/register?role=${r}${nx}" ${r === role ? raw('aria-current="true"') : ''}>${ic(icons[r])}${t('role.' + r)}</a>`)}</div>
      <p class="muted small" >${t('role.' + role + '.d')}</p>
      <form data-form="register" data-role="${role}" data-next="${q.get('next') || ''}">
      ${field('name', 'text', true, 'autocomplete="name"')}${field('email', 'email', true, 'autocomplete="username"')}${field('phone', 'tel', false)}
      ${role === 'patient' ? h`<div class="fgrid">${field('dob', 'date')}<div class="field"><label for="a-bg">${t('f.blood_group')}</label><select id="a-bg" name="blood_group"><option value="">—</option>${BLOOD.map((b) => h`<option>${b}</option>`)}</select></div></div>${field('city', 'text', false)}` : ''}
      ${role === 'doctor' ? h`${field('license_no', 'text')}${field('specialty', 'text')}${field('facility', 'text', false)}<div class="alert amber">${ic('shield-check')}<span>${t('reg.doctor.note')}</span></div>` : ''}
      <div class="field"><label for="a-pw">${t('f.password')}</label><input id="a-pw" name="password" type="password" minlength="10" required autocomplete="new-password"><div class="hint">${t('reg.pw.hint')}</div></div>
      <button class="btn lg block" type="submit">${t('nav.register')}</button></form><p class="muted center">${t('reg.have')} <a data-link href="/login">${t('nav.login')}</a></p>`;
  }
  page(h`<div class="auth">${side}<div class="auth-main"><div class="auth-box"><a class="brand" data-link href="/">${LOGO}<span>${t('brand')}</span></a>${body}</div></div></div>`, { pub: true, nav: false });
}

// ---------- lists (conditions, allergies, medications, contacts) ----------
const FIELDS = {
  conditions: [['name', 'text', 1], ['diagnosed_year', 'number'], ['status', ['active', 'resolved']], ['notes', 'textarea']],
  allergies: [['substance', 'text', 1], ['reaction', 'text'], ['severity', ['mild', 'moderate', 'severe']]],
  medications: [['name', 'text', 1], ['dose', 'text'], ['frequency', 'text'], ['route', ['oral', 'injection', 'inhaled', 'topical', 'drops', 'other']], ['start_date', 'date'], ['end_date', 'date'], ['prescriber', 'text'], ['active', 'check']],
  contacts: [['name', 'text', 1], ['relation', 'text'], ['phone', 'tel', 1], ['is_primary', 'check']],
};
const KIND_UI = { conditions: ['pulse', 'amber'], allergies: ['alert', 'red'], medications: ['pill', 'teal'], contacts: ['phone', 'green'] };
const DEFAULTS = { medications: { active: 1 }, conditions: { status: 'active' } };
function fieldHtml([name, type, req], row, kid) {
  const id = `f-${kid}-${name}`, v = row[name] ?? '';
  if (type === 'check') return h`<div class="check field full"><input type="checkbox" id="${id}" name="${name}" ${row[name] ? 'checked' : ''}><label for="${id}">${t('f.' + name)}</label></div>`;
  let ctl;
  if (Array.isArray(type)) ctl = h`<select id="${id}" name="${name}">${req ? '' : h`<option value="">—</option>`}${type.map((o) => h`<option value="${o}" ${o === v ? 'selected' : ''}>${t('o.' + o)}</option>`)}</select>`;
  else if (type === 'textarea') ctl = h`<textarea id="${id}" name="${name}" maxlength="500">${v}</textarea>`;
  else ctl = h`<input id="${id}" name="${name}" type="${type}" value="${v}" ${req ? 'required' : ''} ${type === 'number' ? raw('min="1900" max="2100"') : ''}>`;
  return h`<div class="field ${type === 'textarea' ? 'full' : ''}"><label for="${id}">${t('f.' + name)}</label>${ctl}</div>`;
}
const kindForm = (pid, kind, row = {}) => {
  const r = row.id ? row : { ...DEFAULTS[kind], ...row }, kid = `${kind}${row.id || 'new'}`;
  return h`<form data-form="kind" data-pid="${pid}" data-kind="${kind}" data-id="${row.id || ''}"><div class="fgrid">${FIELDS[kind].map((f) => fieldHtml(f, r, kid))}</div><button class="btn" type="submit">${ic('check')}${t('save')}</button></form>`;
};
const SUMMARY = {
  conditions: (r) => h`<div class="li-t">${r.name} ${chip(t('o.' + r.status), r.status === 'active' ? 'amber' : '')}</div><div class="li-m">${dots([r.diagnosed_year, r.notes])}</div>`,
  allergies: (r) => h`<div class="li-t">${r.substance} ${r.severity ? chip(t('o.' + r.severity), r.severity === 'severe' ? 'red' : 'amber') : ''}</div><div class="li-m">${r.reaction || ''}</div>`,
  medications: (r) => h`<div class="li-t">${r.name} <span class="ltr">${r.dose || ''}</span> ${chip(t(r.active ? 'o.current' : 'o.stopped'), r.active ? 'green' : '')}</div><div class="li-m">${dots([r.frequency, r.route && t('o.' + r.route), r.prescriber, r.start_date && fmt(r.start_date, false), r.end_date && '→ ' + fmt(r.end_date, false)])}</div>`,
  contacts: (r) => h`<div class="li-t">${r.name} ${r.is_primary ? chip(t('f.is_primary'), 'teal') : ''}</div><div class="li-m"><bdi>${r.relation || ''}</bdi> · <a class="ltr" href="tel:${r.phone}">${r.phone}</a></div>`,
};
const secHead = (icn, tone, title, desc) => h`<div class="card-h"><span class="ico-chip ${tone}">${ic(icn)}</span><div><h2>${title}</h2>${desc ? h`<div class="muted small">${desc}</div>` : ''}</div></div>`;
function listTab(pid, kind, rows) {
  const [icn, tone] = KIND_UI[kind];
  return h`<div class="card">${secHead(icn, tone, t('tab.' + kind), t('hint.' + kind))}
    ${rows.length ? h`<ul class="list">${rows.map((r) => h`<li class="li"><span class="ico-chip ${tone}">${ic(icn)}</span><div>${SUMMARY[kind](r)}</div>
      <div class="li-a"><button class="ibtn" data-act="toggle" data-target="ed-${kind}-${r.id}" aria-label="${t('edit')}" title="${t('edit')}">${ic('edit')}</button>
      <button class="ibtn red" data-act="del" data-pid="${pid}" data-kind="${kind}" data-id="${r.id}" aria-label="${t('delete')}" title="${t('delete')}">${ic('trash')}</button></div>
      <div class="li-form" id="ed-${kind}-${r.id}" hidden>${kindForm(pid, kind, r)}</div></li>`)}</ul>` : h`<div class="empty">${ic(icn)}<span>${t('empty.' + kind)}</span></div>`}
    <button class="btn ghost addbtn block" data-act="toggle" data-target="add-${kind}">${ic('plus')}${t('add.' + kind)}</button>
    <div class="addbox" id="add-${kind}" ${rows.length ? 'hidden' : ''}>${kindForm(pid, kind)}</div></div>`;
}

// ---------- family: dashboard & profile ----------
async function dashboard() {
  const people = S.people;
  if (S.user.role === 'patient' && people.length === 1) return go('/app/p/' + people[0].id, true);
  const canAdd = S.user.role === 'caregiver' || !people.length;
  const pend = people.reduce((a, p) => a + p.pending, 0);
  page(h`<div class="pagehead"><div><h1>${t('dash.hello', { name: S.user.name.split(' ')[0] })}</h1><p class="muted">${t('dash.sub')}</p></div></div>
    ${pend ? h`<div class="alert amber">${ic('clock')}<span>${t('ov.pending', { n: pend })}</span></div>` : ''}
    <div class="people">${people.map((p) => h`<a class="pc" data-link href="/app/p/${p.id}"><div class="top">${av(p.full_name, p.id)}<div class="grow"><h3>${p.full_name}</h3><div class="muted small">${p.blood_group ? h`<span class="ltr">${p.blood_group}</span> · ` : ''}${t('dash.ready')}</div></div>${p.pending ? chip(t('dash.pending', { n: p.pending }), 'red') : ''}</div>
      <div class="ft"><div class="chips">${chip(`${p.medications}`, 'teal', 'pill')}${chip(`${p.allergies}`, 'red', 'alert')}${chip(`${p.contacts}`, 'green', 'phone')}</div>${ring(readiness(p))}</div></a>`)}
      ${canAdd ? h`<button class="pc new" data-act="toggle" data-target="newperson"><span>${ic('plus')}${t('dash.add')}</span></button>` : ''}</div>
    ${canAdd ? h`<div class="card addbox" id="newperson" ${people.length ? 'hidden' : ''}><h2>${t('dash.add')}</h2><form data-form="newpatient"><div class="fgrid">
      <div class="field full"><label for="n-fn">${t('f.full_name')}</label><input id="n-fn" name="full_name" required></div>
      <div class="field"><label for="n-dob">${t('f.dob')}</label><input id="n-dob" name="dob" type="date" required></div>
      <div class="field"><label for="n-bg">${t('f.blood_group')}</label><select id="n-bg" name="blood_group"><option value="">—</option>${BLOOD.map((b) => h`<option>${b}</option>`)}</select></div>
      <div class="field full"><label for="n-c">${t('f.city')}</label><input id="n-c" name="city"></div></div><button class="btn" type="submit">${ic('plus')}${t('dash.create')}</button></form></div>` : ''}`);
}

const TABS = [['overview', 'home'], ['conditions', 'pulse'], ['allergies', 'alert'], ['medications', 'pill'], ['contacts', 'phone'], ['documents', 'file'], ['qr', 'qr'], ['access', 'eye'], ['sharing', 'users']];
function emgPreview(d) {
  const p = d.patient, act = d.medications.filter((m) => m.active), cs = d.conditions.filter((c) => c.status === 'active');
  const none = h`<span class="faint small">${t('emg.nodata')}</span>`;
  return h`<div class="card preview"><header>${ic('alert')}${t('ov.preview')}</header><div class="bd">
    <div class="row"><div class="grow"><h4>${t('f.blood_group')}</h4><div class="blood ltr">${p.blood_group || '—'}</div></div>${p.age != null ? chip(t('age', { n: p.age })) : ''}</div>
    ${p.warnings ? h`<div class="alert red">${ic('alert')}<span>${p.warnings}</span></div>` : ''}
    <div><h4>${t('tab.allergies')}</h4><div class="chips">${d.allergies.length ? d.allergies.map((a) => chip(a.substance, 'red')) : none}</div></div>
    <div><h4>${t('tab.conditions')}</h4><div class="chips">${cs.length ? cs.map((c) => chip(c.name, 'amber')) : none}</div></div>
    <div><h4>${t('tab.medications')}</h4><div class="chips">${act.length ? act.map((m) => chip(`${m.name} ${m.dose || ''}`, 'teal')) : none}</div></div>
    <div><h4>${t('tab.contacts')}</h4><div class="chips">${d.contacts.length ? d.contacts.map((c) => chip(c.name, 'green', 'phone')) : none}</div></div></div></div>`;
}
async function profile(pid, tab) {
  if (!TABS.some(([k]) => k === tab)) tab = 'overview';
  const [d, g] = await Promise.all([api(`/api/patients/${pid}`), api(`/api/patients/${pid}/grants`)]);
  const pending = g.grants.filter((x) => x.status === 'pending'), p = d.patient;
  const counts = { conditions: d.conditions.length, allergies: d.allergies.length, medications: d.medications.length, contacts: d.contacts.length };
  const pct = readiness(counts);
  let body;
  if (tab === 'overview') {
    const done = ['allergies', 'conditions', 'medications', 'contacts'];
    body = h`${pending.length ? h`<div class="alert amber">${ic('clock')}<a data-link href="/app/p/${pid}?tab=access">${t('ov.pending', { n: pending.length })}</a></div>` : ''}
      <div class="two"><div><div class="card">${secHead('user', 'navy', t('ov.basic'))}<form data-form="basic" data-pid="${pid}"><div class="fgrid">
        <div class="field full"><label for="b-fn">${t('f.full_name')}</label><input id="b-fn" name="full_name" value="${p.full_name}" required></div>
        <div class="field"><label for="b-dob">${t('f.dob')}</label><input id="b-dob" name="dob" type="date" value="${p.dob || ''}" required></div>
        <div class="field"><label for="b-bg">${t('f.blood_group')}</label><select id="b-bg" name="blood_group"><option value="">—</option>${BLOOD.map((b) => h`<option ${b === p.blood_group ? 'selected' : ''}>${b}</option>`)}</select></div>
        <div class="field full"><label for="b-c">${t('f.city')}</label><input id="b-c" name="city" value="${p.city || ''}"></div>
        <div class="field full"><label for="b-w">${t('f.warnings')}</label><textarea id="b-w" name="warnings" maxlength="600">${p.warnings || ''}</textarea><div class="hint">${t('hint.warnings')}</div></div></div>
        <button class="btn" type="submit">${ic('check')}${t('save')}</button></form></div>
        <div class="card">${secHead('shield-check', 'teal', t('ov.ready'))}<ul class="list ready">${done.map((k) => h`<li>${counts[k] ? h`<span class="tick-ok">${ic('check')}</span>` : h`<span class="tick-no">${ic('plus')}</span>`}<span class="grow">${t('tab.' + k)}</span>${counts[k] ? chip(t('ov.added', { n: counts[k] }), 'green') : h`<a class="btn sm soft" data-link href="/app/p/${pid}?tab=${k}">${t('ov.todo')}</a>`}</li>`)}</ul></div></div>
        <div>${emgPreview(d)}</div></div>`;
  } else if (FIELDS[tab]) body = listTab(pid, tab, d[tab]);
  else if (tab === 'documents') body = docsTab(pid, d.documents);
  else if (tab === 'qr') body = await qrTab(pid);
  else if (tab === 'access') body = await accessTab(pid, g.grants);
  else body = await sharingTab(pid, d.relation);
  page(h`<div class="phero dark">${av(p.full_name, pid, 'lg')}<div class="grow"><h1>${p.full_name}</h1><div class="meta">${p.age != null ? chip(t('age', { n: p.age }), 'glass') : ''}${p.blood_group ? h`<span class="chip red ltr">${ic('drop')}${p.blood_group}</span>` : ''}${p.city ? chip(p.city, 'glass', 'home') : ''}</div></div>${ring(pct)}</div>
    <div class="stats">${[['allergies', 'alert', 'red'], ['conditions', 'pulse', 'amber'], ['medications', 'pill', 'teal'], ['contacts', 'phone', 'green']].map(([k, i, tone]) => h`<a class="stat" data-link href="/app/p/${pid}?tab=${k}"><span class="ico-chip ${tone}">${ic(i)}</span><div><b>${counts[k]}</b><small>${t('tab.' + k)}</small></div></a>`)}</div>
    <nav class="tabs" aria-label="${t('tabs')}">${TABS.map(([k, i]) => h`<a data-link href="/app/p/${pid}?tab=${k}" ${k === tab ? raw('aria-current="page"') : ''}>${ic(i)}${t('tab.' + k)}${k === 'access' && pending.length ? h`<span class="cnt">${pending.length}</span>` : ''}</a>`)}</nav>${body}`);
}

function docsTab(pid, docs) {
  return h`<div class="card">${secHead('file', '', t('tab.documents'), t('hint.documents'))}
    ${docs.length ? h`<ul class="list">${docs.map((d) => h`<li class="li"><span class="fileic ${d.mime === 'application/pdf' ? 'pdf' : ''}">${ic(d.mime === 'application/pdf' ? 'file' : 'image')}</span><div><div class="li-t">${d.title} ${chip(t('c.' + d.category))}</div><div class="li-m">${dots([fmt(d.created_at), `${(d.size / 1024).toFixed(0)} KB`, d.mime === 'application/pdf' ? 'PDF' : 'IMG'])}</div></div>
      <div class="li-a"><a class="ibtn" target="_blank" rel="noopener" href="/api/documents/${d.id}/file" aria-label="${t('open')}" title="${t('open')}">${ic('external')}</a><button class="ibtn red" data-act="deldoc" data-pid="${pid}" data-id="${d.id}" aria-label="${t('delete')}" title="${t('delete')}">${ic('trash')}</button></div></li>`)}</ul>` : h`<div class="empty">${ic('file')}<span>${t('empty.documents')}</span></div>`}
    <button class="btn ghost addbtn block" data-act="toggle" data-target="add-doc">${ic('upload')}${t('add.documents')}</button>
    <div class="addbox" id="add-doc" ${docs.length ? 'hidden' : ''}><form data-form="upload" data-pid="${pid}"><div class="fgrid">
      <div class="field"><label for="u-t">${t('f.title')}</label><input id="u-t" name="title" required maxlength="120"></div>
      <div class="field"><label for="u-c">${t('f.category')}</label><select id="u-c" name="category">${['xray', 'mri', 'ct', 'ultrasound', 'lab', 'prescription', 'discharge', 'report', 'vaccination', 'other'].map((c) => h`<option value="${c}">${t('c.' + c)}</option>`)}</select></div>
      <div class="field full"><label class="drop" for="u-f">${ic('upload')}<span id="u-name">${t('upload.choose')}</span><span class="hint">${t('hint.upload')}</span><input id="u-f" name="file" type="file" accept="application/pdf,image/png,image/jpeg" required data-change="file"></label></div></div>
      <button class="btn" type="submit">${ic('upload')}${t('upload')}</button></form></div></div>`;
}

// ---------- the medical ID card ----------
const cardOpts = { blood: false, phone: false };
const idFront = (q, o = {}) => h`<div class="idc"><div class="hd"><span class="lg">${LOGO}<span>${DICT.en.brand} · ${DICT.ar.brand}</span></span><span class="tg">${DICT.en['card.front']}<br>${DICT.ar['card.front']}</span></div>
  <div class="bd"><div><div class="nm" dir="auto">${q.name}</div><div class="meta">${o.blood && q.blood_group ? h`<span class="bl">${q.blood_group}</span>` : ''}${o.phone && q.phone ? h`<span>${q.phone}</span>` : ''}</div></div><div class="qrw">${raw(q.svg)}</div></div>
  <div class="ft"><span>${DICT.en['card.scan.s']}</span><span dir="rtl">${DICT.ar['card.scan.s']}</span></div></div>`;
const idBack = (host) => h`<div class="idc back"><div class="band"><span>${DICT.en['card.back.t']}</span><span dir="rtl">${DICT.ar['card.back.t']}</span></div>
  <div class="txt"><div><b>${DICT.en['card.back.pro']}</b>${DICT.en['card.back.d']}</div><div class="ar"><b>${DICT.ar['card.back.pro']}</b>${DICT.ar['card.back.d']}</div></div><div class="host ltr">${host}</div></div>`;

async function qrTab(pid) {
  const q = await api(`/api/patients/${pid}/qr`);
  return h`<div class="qr-grid"><div class="stage">${idFront(q, { blood: true })}</div>
    <div class="card">${secHead('qr', 'teal', t('qr.title'))}<p class="muted">${t('qr.desc')}</p><div class="row"><a class="btn" data-link href="/card/${pid}">${ic('print')}${t('qr.print')}</a><button class="btn ghost" data-act="copy" data-text="${q.url}">${ic('copy')}${t('qr.copy')}</button></div>
      <hr class="rule"><p class="muted small">${t('qr.rotated', { d: fmt(q.rotated_at, false) })}</p><button class="btn ghost sm" data-act="rotate" data-pid="${pid}">${ic('refresh')}${t('qr.rotate')}</button><p class="hint">${t('qr.rotate.hint')}</p></div></div>`;
}
async function cardView(pid) {
  const q = await api(`/api/patients/${pid}/qr`), host = new URL(q.url).host;
  page(h`<div class="noprint"><a data-link href="/app/p/${pid}?tab=qr" class="muted">← ${t('tab.qr')}</a>
    <div class="pagehead"><div><h1>${t('card.title')}</h1><p class="muted">${t('card.desc')}</p></div><button class="btn lg" data-act="print">${ic('print')}${t('card.print')}</button></div>
    <div class="card"><div class="row"><div class="check"><input type="checkbox" id="o-b" data-change="cardopt" data-k="blood" ${cardOpts.blood ? 'checked' : ''}><label for="o-b">${t('card.opt.blood')}</label></div>
    <div class="check"><input type="checkbox" id="o-p" data-change="cardopt" data-k="phone" ${cardOpts.phone ? 'checked' : ''}><label for="o-p">${t('card.opt.phone')}</label></div></div><p class="hint">${t('card.opt.hint')}</p></div></div>
    <div class="stage sheetstage"><div class="sheet"><figure>${idFront(q, cardOpts)}<figcaption>${t('card.lbl.front')}</figcaption></figure><figure>${idBack(host)}<figcaption>${t('card.lbl.back')}</figcaption></figure></div></div>`);
}

// ---------- family: access, sharing ----------
const ACTION_UI = { scan: ['eye', ''], access_requested: ['clock', 'amber'], grant_approve: ['check', 'green'], grant_deny: ['x', 'red'], grant_revoke: ['x', 'amber'], view_record: ['eye', 'teal'], document_viewed: ['file', 'teal'], document_uploaded: ['upload', ''], document_deleted: ['trash', ''], emergency_access: ['alert', 'red'], qr_rotated: ['refresh', 'amber'], profile_created: ['sparkle', 'teal'], profile_updated: ['edit', ''], caregiver_added: ['users', ''], caregiver_removed: ['users', ''] };
const actionLabel = (a) => {
  const m = /^(add|edit|delete)_(conditions|allergies|medications|contacts)$/.exec(a);
  return m ? t('a.' + m[1], { what: t('tab.' + m[2]) }) : (DICT[S.lang]['a.' + a] ?? DICT.en['a.' + a] ?? a);
};
async function accessTab(pid, grants) {
  const { log } = await api(`/api/patients/${pid}/access-log`);
  const live = (g) => g.status === 'active' && g.expires_at > new Date().toISOString();
  const who = (g) => h`<div class="li-t">${g.doctor_name}</div><div class="li-m">${dots([g.specialty, g.facility, g.license_no && `${t('f.license_no')}: ${g.license_no}`])}</div>`;
  const pend = grants.filter((g) => g.status === 'pending'), act = grants.filter(live);
  const detail = (e) => { if (!e.detail) return ''; try { const d = JSON.parse(e.detail); return d.reason ? h`<div class="li-m"><b>${t('r.' + d.reason)}</b> — ${d.justification}</div>` : ''; } catch { return ''; } };
  return h`${pend.length ? h`<div class="card emg-card">${secHead('clock', 'amber', t('acc.pending'), t('acc.pending.d'))}<ul class="list">${pend.map((g) => h`<li class="li"><span class="ico-chip navy">${ic('stethoscope')}</span><div>${who(g)}<div class="li-m">${fmt(g.requested_at)}</div></div>
      <div class="row"><select id="dur-${g.id}" aria-label="${t('acc.duration')}"><option value="24">${t('acc.24h')}</option><option value="168">${t('acc.7d')}</option><option value="720">${t('acc.30d')}</option></select>
      <button class="btn teal sm" data-act="grant" data-pid="${pid}" data-id="${g.id}" data-d="approve">${ic('check')}${t('acc.approve')}</button><button class="btn ghost sm" data-act="grant" data-pid="${pid}" data-id="${g.id}" data-d="deny">${t('acc.deny')}</button></div></li>`)}</ul></div>` : ''}
    <div class="card">${secHead('shield-check', 'green', t('acc.active'))}${act.length ? h`<ul class="list">${act.map((g) => h`<li class="li"><span class="ico-chip green">${ic('stethoscope')}</span><div>${who(g)}<div class="li-m">${t('acc.until', { d: fmt(g.expires_at) })}</div></div><button class="btn ghost sm" data-act="grant" data-pid="${pid}" data-id="${g.id}" data-d="revoke">${t('acc.revoke')}</button></li>`)}</ul>` : h`<div class="empty">${ic('lock')}<span>${t('acc.none')}</span></div>`}</div>
    <div class="card">${secHead('list', '', t('acc.history'), t('acc.history.d'))}<ul class="tl">${log.map((e) => { const [i, tone] = ACTION_UI[e.action] || (/^(add|edit|delete)_/.test(e.action) ? ['edit', ''] : ['sparkle', '']); return h`<li class="${e.action === 'emergency_access' ? 'em-row' : ''}"><span class="ico-chip ${tone}">${ic(i)}</span><div class="grow"><div class="li-t">${actionLabel(e.action)}</div><div class="li-m">${dots([e.actor_name, e.specialty, e.facility])}</div>${detail(e)}</div><time class="when">${fmt(e.ts)}</time></li>`; })}</ul></div>`;
}
async function sharingTab(pid, relation) {
  const { members } = await api(`/api/patients/${pid}/members`);
  return h`<div class="card">${secHead('users', 'amber', t('tab.sharing'), t('share.desc'))}<ul class="list">${members.map((m) => h`<li class="li">${av(m.name, m.id)}<div><div class="li-t">${m.name} ${chip(t('share.' + m.relation), m.relation === 'owner' ? 'teal' : '')}</div><div class="li-m ltr">${m.email}</div></div>
    ${relation === 'owner' && m.relation !== 'owner' ? h`<button class="btn ghost sm" data-act="rmmember" data-pid="${pid}" data-id="${m.id}">${t('share.remove')}</button>` : h`<span></span>`}</li>`)}</ul>
    ${relation === 'owner' ? h`<button class="btn ghost addbtn block" data-act="toggle" data-target="add-member">${ic('plus')}${t('share.add')}</button><div class="addbox" id="add-member" hidden><form data-form="addmember" data-pid="${pid}"><div class="field"><label for="m-e">${t('f.email')}</label><input id="m-e" name="email" type="email" required><div class="hint">${t('share.hint')}</div></div><button class="btn" type="submit">${ic('plus')}${t('share.add')}</button></form></div>` : ''}</div>`;
}

// ---------- doctor ----------
const verifiedChip = () => (S.user.doc_status === 'approved' ? chip(t('gs.approved'), 'green', 'shield-check') : S.user.doc_status === 'rejected' ? chip(t('gs.rejected'), 'red') : chip(t('gs.pending'), 'amber', 'clock'));
function doctorBanner() {
  const s = S.user.doc_status;
  return s === 'rejected' ? h`<div class="alert red">${ic('x')}<span>${t('doc.rejected')} ${S.user.doc_note || ''}</span></div>` : s === 'pending' ? h`<div class="alert amber">${ic('clock')}<span>${t('doc.pending')}</span></div>` : '';
}
async function doctorHome() {
  const ok = S.user.doc_status === 'approved';
  const g = ok ? (await api('/api/doctor/grants')).grants : [];
  const st = { active: 'green', pending: 'amber', denied: 'red', revoked: 'red', expired: '' };
  page(h`<div class="pagehead"><div><h1>${t('doc.title')}</h1><p class="muted">${dots([S.user.name, S.user.specialty, S.user.facility])}</p></div>${verifiedChip()}</div>${doctorBanner()}
    ${ok ? h`<div class="scanhero"><h2>${t('doc.scan')}</h2><p>${t('doc.scan.d')}</p>
      <form data-form="scanmanual" class="row"><input class="grow" name="link" placeholder="${t('doc.paste')}" required aria-label="${t('doc.paste')}"><button class="btn teal" type="submit">${ic('qr')}${t('doc.open')}</button></form>
      ${'BarcodeDetector' in window ? h`<p><button class="btn line-light" data-act="cam">${ic('camera')}${t('doc.camera')}</button></p><video id="cam" class="vid" playsinline muted hidden></video>` : h`<p class="small">${t('doc.nocam')}</p>`}</div>
      <div class="card">${secHead('users', '', t('doc.recent'))}${g.length ? h`<ul class="list">${g.map((x) => h`<li class="li">${av(x.full_name, x.patient_id)}<div><div class="li-t">${x.full_name}</div><div class="li-m">${fmt(x.requested_at)}${x.status === 'active' ? ' · ' + t('acc.until', { d: fmt(x.expires_at) }) : ''}</div></div>
        <div class="row">${chip(t('gs.' + x.status), st[x.status])}${x.status === 'active' ? h`<a class="btn sm" data-link href="/doctor/p/${x.patient_id}">${t('doc.open')}</a>` : ''}</div></li>`)}</ul>` : h`<div class="empty">${ic('qr')}<span>${t('doc.none')}</span></div>`}</div>` : ''}`);
}
async function scanView(token) {
  if (!S.user) return go('/login?next=' + encodeURIComponent('/s/' + token), true);
  if (S.user.role !== 'doctor') return page(h`<div class="gate card"><div class="lock">${ic('stethoscope')}</div><h1>${t('scan.family.t')}</h1><p class="muted">${t('scan.family.d')}</p><a class="btn" data-link href="${roleHome(S.user.role)}">${t('home')}</a></div>`);
  if (S.user.doc_status !== 'approved') return page(h`<div class="gate">${doctorBanner()}</div>`);
  let r;
  try { r = await api('/api/scan/' + token); } catch (e) { if (e.code === 'invalid_qr') return page(h`<div class="gate"><div class="alert red">${ic('alert')}<span>${t('err.invalid_qr')}</span></div></div>`); throw e; }
  if (r.access === 'granted') return go('/doctor/p/' + r.patient.id, true);
  page(h`<div class="gate"><div class="card"><div class="lock">${ic('lock')}</div><p class="muted">${t('scan.patient')}</p><h1>${r.patient.display}</h1><p class="muted">${t('scan.locked')}</p>
    ${r.access === 'pending' ? h`<div class="alert amber">${ic('clock')}<span>${t('scan.pending')}</span></div><button class="btn ghost" data-act="reload">${ic('refresh')}${t('scan.refresh')}</button>` : h`<button class="btn lg block" data-act="request" data-token="${token}">${ic('key')}${t('scan.request')}</button>`}</div>
    <div class="card emg-card" ><div class="card-h"><span class="ico-chip red">${ic('alert')}</span><h2>${t('emg.title')}</h2></div><p class="muted">${t('emg.desc')}</p>
      <button class="btn danger block" data-act="toggle" data-target="emgform">${t('emg.open')}</button>
      <form data-form="emergency" data-token="${token}" id="emgform" class="addbox" hidden>
        <div class="field"><label for="e-r">${t('emg.reason')}</label><select id="e-r" name="reason" required>${['unconscious', 'cardiac', 'respiratory', 'trauma', 'confused', 'other'].map((x) => h`<option value="${x}">${t('r.' + x)}</option>`)}</select></div>
        <div class="field"><label for="e-j">${t('emg.just')}</label><textarea id="e-j" name="justification" minlength="10" maxlength="500" required></textarea><div class="hint">${t('emg.just.hint')}</div></div>
        <div class="check field"><input type="checkbox" id="e-c" name="confirm" required><label for="e-c">${t('emg.confirm')}</label></div>
        <button class="btn danger block" type="submit">${t('emg.go')}</button></form></div></div>`);
}
function emergencyView(e) {
  const none = h`<span class="faint">${t('emg.nodata')}</span>`;
  const sec = (i, k, inner) => h`<section><h3>${ic(i)}${t(k)}</h3>${inner}</section>`;
  page(h`<div class="emg-panel"><header>${ic('alert')}${t('emg.banner')}</header>
    <section><div class="row"><div class="grow"><h1>${e.patient.full_name}</h1>${e.patient.age != null ? chip(t('age', { n: e.patient.age })) : ''}</div><div class="center"><div class="faint small">${t('f.blood_group')}</div><div class="bigblood ltr">${e.patient.blood_group || '—'}</div></div></div></section>
    ${e.patient.warnings ? h`<section><div class="hl">${ic('alert')}<span>${e.patient.warnings}</span></div></section>` : ''}
    ${sec('alert', 'tab.allergies', e.allergies.length ? h`<ul class="list">${e.allergies.map((a) => h`<li class="li"><span class="ico-chip red">${ic('alert')}</span><div><div class="li-t">${a.substance} ${a.severity ? chip(t('o.' + a.severity), a.severity === 'severe' ? 'red' : 'amber') : ''}</div><div class="li-m">${a.reaction || ''}</div></div><span></span></li>`)}</ul>` : none)}
    ${sec('pulse', 'tab.conditions', e.conditions.length ? h`<div class="chips">${e.conditions.map((c) => chip(c.name, 'amber'))}</div>` : none)}
    ${sec('pill', 'tab.medications', e.medications.length ? h`<ul class="list">${e.medications.map((m) => h`<li class="li"><span class="ico-chip teal">${ic('pill')}</span><div><div class="li-t">${m.name} <span class="ltr">${m.dose || ''}</span></div><div class="li-m">${dots([m.frequency, m.route && t('o.' + m.route)])}</div></div><span></span></li>`)}</ul>` : none)}
    ${sec('phone', 'tab.contacts', e.contacts.length ? h`<ul class="list">${e.contacts.map((c) => h`<li class="li"><span class="ico-chip green">${ic('phone')}</span><div><div class="li-t">${c.name}</div><div class="li-m">${c.relation || ''}</div></div><a class="btn sm teal" href="tel:${c.phone}"><span class="ltr">${c.phone}</span></a></li>`)}</ul>` : none)}
    <section class="muted small">${ic('lock')} ${t('emg.logged')}</section></div><p><a class="btn ghost" data-link href="/doctor">${t('home')}</a></p>`);
}
async function recordView(pid) {
  const d = await api(`/api/doctor/patients/${pid}/record`).catch((e) => { if (e.code === 'no_access') return null; throw e; });
  if (!d) return page(h`<div class="gate"><div class="alert red">${ic('lock')}<span>${t('err.no_access')}</span></div></div>`);
  const p = d.patient, list = (k, tone) => h`<div class="card">${secHead(KIND_UI[k][0], KIND_UI[k][1], t('tab.' + k))}${d[k].length ? h`<ul class="list">${d[k].map((r) => h`<li class="li"><span class="ico-chip ${KIND_UI[k][1]}">${ic(KIND_UI[k][0])}</span><div>${SUMMARY[k](r)}</div><span></span></li>`)}</ul>` : h`<span class="faint">${t('emg.nodata')}</span>`}</div>`;
  page(h`<a data-link href="/doctor" class="muted">← ${t('nav.doctor')}</a><div class="phero dark">${av(p.full_name, pid, 'lg')}<div class="grow"><h1>${p.full_name}</h1><div class="meta">${p.age != null ? chip(t('age', { n: p.age }), 'glass') : ''}${p.blood_group ? h`<span class="chip red ltr">${ic('drop')}${p.blood_group}</span>` : ''}${chip(t('acc.until', { d: fmt(d.expires_at) }), 'glass', 'clock')}</div></div></div>
    <p class="muted small">${ic('eye')} ${t('rec.logged')}</p>
    ${p.warnings ? h`<div class="hl">${ic('alert')}<span>${p.warnings}</span></div>` : ''}
    <div class="two"><div>${list('allergies')}${list('conditions')}</div><div>${list('medications')}${list('contacts')}</div></div>
    <div class="card">${secHead('file', '', t('tab.documents'))}${d.documents.length ? h`<ul class="list">${d.documents.map((x) => h`<li class="li"><span class="fileic ${x.mime === 'application/pdf' ? 'pdf' : ''}">${ic(x.mime === 'application/pdf' ? 'file' : 'image')}</span><div><div class="li-t">${x.title} ${chip(t('c.' + x.category))}</div><div class="li-m">${fmt(x.created_at)}</div></div><a class="ibtn" target="_blank" rel="noopener" href="/api/documents/${x.id}/file" aria-label="${t('open')}">${ic('external')}</a></li>`)}</ul>` : h`<span class="faint">${t('emg.nodata')}</span>`}</div>`);
}

// ---------- admin ----------
async function adminView() {
  const q = new URLSearchParams(location.search), tab = q.get('tab') || 'doctors', st = q.get('st') || 'pending';
  let body;
  if (tab === 'doctors') {
    const { doctors } = await api('/api/admin/doctors?status=' + st);
    body = h`<div class="seg">${['pending', 'approved', 'rejected'].map((s) => h`<a data-link href="/admin?tab=doctors&st=${s}" ${s === st ? raw('aria-current="true"') : ''}>${t('gs.' + s)}</a>`)}</div><br>
      <div class="card">${doctors.length ? h`<ul class="list">${doctors.map((d) => h`<li class="li">${av(d.name, d.id)}<div><div class="li-t">${d.name} ${chip(d.specialty, 'teal')}</div><div class="li-m">${dots([d.facility])}</div>
        <div class="li-m">${t('f.license_no')}: <b class="ltr">${d.license_no}</b> · <span class="ltr">${d.email}</span> ${d.phone ? h`· <span class="ltr">${d.phone}</span>` : ''}</div><div class="li-m">${fmt(d.created_at)}${d.doc_note ? ' · ' + d.doc_note : ''}</div></div>
        <div class="li-a">${st !== 'approved' ? h`<button class="btn teal sm" data-act="verify" data-id="${d.id}" data-s="approved">${ic('shield-check')}${t('adm.approve')}</button>` : ''}${st !== 'rejected' ? h`<button class="btn ghost sm" data-act="verify" data-id="${d.id}" data-s="rejected">${t('adm.reject')}</button>` : ''}</div></li>`)}</ul>` : h`<div class="empty">${ic('check')}<span>${t('adm.none')}</span></div>`}</div>`;
  } else if (tab === 'stats') {
    const s = await api('/api/admin/stats'), n = (r) => s.users.find((u) => u.role === r)?.n || 0;
    const kpi = (i, tone, label, v, cls = '') => h`<div class="kpi ${cls}"><span class="ico-chip ${tone}">${ic(i)}</span><b>${v}</b><small>${label}</small></div>`;
    body = h`<div class="kpis">${kpi('users', 'amber', t('adm.families'), n('caregiver') + n('patient'))}${kpi('stethoscope', 'teal', t('adm.doctors'), n('doctor'))}${kpi('heart', '', t('adm.patients'), s.patients)}${kpi('clock', 'amber', t('adm.pending'), s.pending_doctors, s.pending_doctors ? 'warn' : '')}</div>
      <div class="kpis">${kpi('alert', 'red', t('adm.emg30'), s.emergencies_30d, s.emergencies_30d ? 'red' : '')}</div>`;
  } else {
    const a = await api('/api/admin/audit');
    const tone = (x) => (x.includes('emergency') ? 'red' : x.includes('approved') || x === 'login' ? 'green' : x.includes('rejected') || x.includes('failed') ? 'amber' : '');
    body = h`<div class="alert ${a.chain.ok ? 'green' : 'red'}">${ic(a.chain.ok ? 'shield-check' : 'alert')}<span>${a.chain.ok ? t('adm.chain.ok', { n: a.chain.checked }) : t('adm.chain.bad', { n: a.chain.brokenAt })}</span></div>
      <div class="card tablewrap"><table><thead><tr><th>${t('adm.time')}</th><th>${t('adm.actor')}</th><th>${t('adm.action')}</th><th>${t('adm.patient')}</th></tr></thead><tbody>${a.log.map((e) => h`<tr><td>${fmt(e.ts)}</td><td>${e.actor_name || '—'} <span class="faint small">${e.actor_role || ''}</span></td><td><span class="chip ${tone(e.action)} ltr">${e.action}</span></td><td>${e.patient_id ?? ''}</td></tr>`)}</tbody></table></div>`;
  }
  page(h`<div class="pagehead"><div><h1>${t('adm.title')}</h1><p class="muted">${t('adm.privacy')}</p></div></div>${body}`);
}

// ---------- actions ----------
let camStream = null;
function stopCam() { camStream?.getTracks().forEach((x) => x.stop()); camStream = null; }
const extractToken = (s) => String(s).trim().match(/([A-Za-z0-9_-]{20,64})\/?$/)?.[1];
const ACTS = {
  lang() { setLang(S.lang === 'ar' ? 'en' : 'ar'); route(); },
  big() { const on = document.documentElement.classList.toggle('big'); localStorage.setItem('big', on ? '1' : '0'); route(); },
  async logout() { await api('/api/logout', { method: 'POST' }).catch(() => {}); S.user = null; S.csrf = null; await loadMe(); go('/'); },
  reload() { route(); },
  toggle(b) { const el = document.getElementById(b.dataset.target); if (el) { el.hidden = !el.hidden; if (!el.hidden) el.querySelector('input,select,textarea')?.focus(); } },
  print() { window.print(); },
  async copy(b) { await navigator.clipboard?.writeText(b.dataset.text); toast(t('copied')); },
  async del(b) { if (!confirm(t('confirm.delete'))) return; try { await api(`/api/patients/${b.dataset.pid}/${b.dataset.kind}/${b.dataset.id}`, { method: 'DELETE' }); toast(t('deleted')); route(); } catch (e) { fail(e); } },
  async deldoc(b) { if (!confirm(t('confirm.delete'))) return; try { await api(`/api/patients/${b.dataset.pid}/documents/${b.dataset.id}`, { method: 'DELETE' }); toast(t('deleted')); route(); } catch (e) { fail(e); } },
  async rotate(b) { if (!confirm(t('qr.rotate.confirm'))) return; try { await api(`/api/patients/${b.dataset.pid}/qr/rotate`, { method: 'POST' }); toast(t('qr.rotated.ok')); route(); } catch (e) { fail(e); } },
  async grant(b) { try { await api(`/api/patients/${b.dataset.pid}/grants/${b.dataset.id}`, { method: 'POST', body: { decision: b.dataset.d, hours: $(`#dur-${b.dataset.id}`)?.value } }); toast(t('saved')); route(); } catch (e) { fail(e); } },
  async rmmember(b) { if (!confirm(t('confirm.delete'))) return; try { await api(`/api/patients/${b.dataset.pid}/members/${b.dataset.id}`, { method: 'DELETE' }); route(); } catch (e) { fail(e); } },
  async request(b) { try { await api(`/api/scan/${b.dataset.token}/request`, { method: 'POST' }); route(); } catch (e) { fail(e); } },
  async verify(b) { const note = b.dataset.s === 'rejected' ? prompt(t('adm.reason')) : null; if (b.dataset.s === 'rejected' && note === null) return; try { await api(`/api/admin/doctors/${b.dataset.id}`, { method: 'POST', body: { status: b.dataset.s, note } }); toast(t('saved')); route(); } catch (e) { fail(e); } },
  async cam() {
    const v = $('#cam');
    try {
      camStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      v.srcObject = camStream; v.hidden = false; await v.play();
      const det = new BarcodeDetector({ formats: ['qr_code'] });
      const tick = async () => { if (!camStream) return; try { const c = await det.detect(v); const tk = c[0] && extractToken(c[0].rawValue); if (tk) { stopCam(); return go('/s/' + tk); } } catch { /* keep scanning */ } requestAnimationFrame(tick); };
      tick();
    } catch { toast(t('err.camera'), true); }
  },
};
const CHG = { cardopt(el) { cardOpts[el.dataset.k] = el.checked; route(); }, file(el) { const n = document.getElementById('u-name'); if (n && el.files[0]) n.textContent = el.files[0].name; } };
const fd = (f) => { const o = {}; for (const el of f.elements) if (el.name && el.type !== 'file') o[el.name] = el.type === 'checkbox' ? el.checked : el.value; return o; };
const FORMS = {
  async login(f) {
    try { await api('/api/login', { method: 'POST', body: fd(f) }); await loadMe(); go(safeNext(f.dataset.next) || roleHome(S.user.role)); } catch (e) { fail(e); }
  },
  async register(f) {
    try { await api('/api/register', { method: 'POST', body: { ...fd(f), role: f.dataset.role } }); await loadMe(); go(safeNext(f.dataset.next) || roleHome(S.user.role)); } catch (e) { fail(e); }
  },
  async newpatient(f) { try { const r = await api('/api/patients', { method: 'POST', body: fd(f) }); go('/app/p/' + r.id); } catch (e) { fail(e); } },
  async basic(f) { try { await api(`/api/patients/${f.dataset.pid}`, { method: 'PUT', body: fd(f) }); toast(t('saved')); route(); } catch (e) { fail(e); } },
  async kind(f) {
    const { pid, kind, id } = f.dataset;
    try { await api(`/api/patients/${pid}/${kind}${id ? '/' + id : ''}`, { method: id ? 'PUT' : 'POST', body: fd(f) }); toast(t('saved')); route(); } catch (e) { fail(e); }
  },
  async upload(f) {
    const file = f.elements.file.files[0]; if (!file) return;
    if (file.size > 10 * 1024 * 1024) return toast(t('err.too_large'), true);
    try { await api(`/api/patients/${f.dataset.pid}/documents`, { method: 'POST', rawBody: file, headers: { 'X-Title': encodeURIComponent(f.elements.title.value), 'X-Category': f.elements.category.value, 'Content-Type': file.type || 'application/octet-stream' } }); toast(t('saved')); route(); } catch (e) { fail(e); }
  },
  async addmember(f) { try { await api(`/api/patients/${f.dataset.pid}/members`, { method: 'POST', body: fd(f) }); toast(t('saved')); route(); } catch (e) { fail(e); } },
  scanmanual(f) { const tk = extractToken(f.elements.link.value); tk ? go('/s/' + tk) : toast(t('err.invalid_qr'), true); },
  async emergency(f) {
    try { const e = await api(`/api/scan/${f.dataset.token}/emergency`, { method: 'POST', body: fd(f) }); emergencyView(e, f.dataset.token); } catch (e) { fail(e); }
  },
};

document.addEventListener('click', (e) => {
  const a = e.target.closest('a[data-link]');
  if (a && !e.metaKey && !e.ctrlKey && !e.shiftKey) { e.preventDefault(); go(a.getAttribute('href')); return; }
  const b = e.target.closest('[data-act]');
  if (b) ACTS[b.dataset.act]?.(b);
});
document.addEventListener('change', (e) => { const c = e.target.closest('[data-change]'); if (c) CHG[c.dataset.change]?.(c); });
document.addEventListener('submit', (e) => { const f = e.target.closest('form[data-form]'); if (f) { e.preventDefault(); FORMS[f.dataset.form]?.(f); } });
window.addEventListener('popstate', () => route());

// ---------- router ----------
function go(path, replace) { history[replace ? 'replaceState' : 'pushState']({}, '', path); return route(); }
const need = (roles) => { if (!S.user) { go('/login?next=' + encodeURIComponent(location.pathname + location.search), true); return false; } if (!roles.includes(S.user.role)) { go(roleHome(S.user.role), true); return false; } return true; };
let routeSeq = 0;
async function route() {
  const seq = ++routeSeq, p = location.pathname, q = new URLSearchParams(location.search);
  try {
    await loadMe();
    S.people = S.user && ['patient', 'caregiver'].includes(S.user.role) ? (await api('/api/patients')).patients : [];
    if (seq !== routeSeq) return;
    let m;
    if (p === '/') return await landing();
    if (p === '/login') return authView('login');
    if (p === '/register') return authView('register');
    if ((m = p.match(/^\/s\/([\w-]+)$/))) return await scanView(m[1]);
    if (p === '/app') return need(['patient', 'caregiver']) && (await dashboard());
    if ((m = p.match(/^\/app\/p\/(\d+)$/))) return need(['patient', 'caregiver']) && (await profile(m[1], q.get('tab')));
    if ((m = p.match(/^\/card\/(\d+)$/))) return need(['patient', 'caregiver']) && (await cardView(m[1]));
    if (p === '/doctor') return need(['doctor']) && (await doctorHome());
    if ((m = p.match(/^\/doctor\/p\/(\d+)$/))) return need(['doctor']) && (S.user.doc_status === 'approved' ? await recordView(m[1]) : go('/doctor', true));
    if (p === '/admin') return need(['admin']) && (await adminView());
    page(wrap(h`<div class="card narrow center"><h1>404</h1><a class="btn" data-link href="/">${t('home')}</a></div>`));
  } catch (e) {
    if (e.status === 401) return go('/login?next=' + encodeURIComponent(p + location.search), true);
    if (e.status === 404) return page(wrap(h`<div class="alert red narrow">${t('err.not_found')}</div>`));
    console.error(e); page(wrap(h`<div class="alert red narrow">${DICT[S.lang]['err.' + e.code] || t('err.server')}</div>`));
  }
}
route();
