// Custom illustrations (inline SVG). Brand: navy #0A1F44, teal #2CC5B4, sky #E8F1FB.
const parseQr = (svg) => { const vb = /viewBox="([^"]+)"/.exec(svg || ''); const d = /<path d="([^"]+)"/.exec(svg || ''); return vb && d ? { vb: vb[1], d: d[1] } : null; };
const qrAt = (q, x, y, s, fg = '#0A1F44') => {
  if (!q) return `<rect x="${x + s * .1}" y="${y + s * .1}" width="${s * .8}" height="${s * .8}" rx="4" fill="${fg}" opacity=".15"/>`;
  const n = Number(q.vb.split(' ')[2]) || 1;
  return `<g transform="translate(${x} ${y}) scale(${(s / n).toFixed(4)})"><path d="${q.d}" fill="${fg}"/></g>`;
};

export const defs = `<svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false"><defs>
<linearGradient id="gTeal" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5ADBCB"/><stop offset="1" stop-color="#1AA6C4"/></linearGradient>
<linearGradient id="gNavy" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#1B4690"/><stop offset="1" stop-color="#0A1F44"/></linearGradient>
<linearGradient id="gSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#F4F8FD"/><stop offset="1" stop-color="#E3EEFA"/></linearGradient>
</defs></svg>`.replace(' style="position:absolute"', ' class="defs"');

export const logo = (cls = '') => `<svg class="logo ${cls}" viewBox="0 0 48 48" aria-hidden="true"><rect width="48" height="48" rx="13" fill="url(#gNavy)"/><path d="M24 9.5 36 14v8.6c0 7.6-5 13-12 15.4-7-2.4-12-7.8-12-15.4V14z" fill="none" stroke="#fff" stroke-opacity=".92" stroke-width="2.4" stroke-linejoin="round"/><path d="M14.5 24h5l2-4.5 3.4 9 2-4.5h4.6" fill="none" stroke="url(#gTeal)" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

export function heroArt(demoSvg) {
  const q = parseQr(demoSvg);
  return `<svg class="art-hero" viewBox="0 0 540 580" role="img" aria-hidden="true">
  <defs>
    <radialGradient id="hb" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#2CC5B4" stop-opacity=".55"/><stop offset=".6" stop-color="#1B4690" stop-opacity=".25"/><stop offset="1" stop-color="#0A1F44" stop-opacity="0"/></radialGradient>
    <filter id="sh" x="-30%" y="-30%" width="160%" height="170%"><feDropShadow dx="0" dy="14" stdDeviation="14" flood-color="#030c20" flood-opacity=".38"/></filter>
    <filter id="sh2" x="-30%" y="-30%" width="160%" height="170%"><feDropShadow dx="0" dy="5" stdDeviation="5" flood-color="#0A1F44" flood-opacity=".12"/></filter>
    <clipPath id="scr"><rect x="168" y="62" width="204" height="438" rx="30"/></clipPath>
  </defs>
  <circle cx="270" cy="300" r="250" fill="url(#hb)"/>
  <circle cx="270" cy="300" r="214" fill="none" stroke="#fff" stroke-opacity=".09"/>
  <circle cx="270" cy="300" r="256" fill="none" stroke="#fff" stroke-opacity=".07" stroke-dasharray="2 9" class="spin"/>
  <g class="phone" filter="url(#sh)">
    <rect x="156" y="50" width="228" height="462" rx="40" fill="#0b1b3d" stroke="#2c4c88" stroke-width="2"/>
    <rect x="168" y="62" width="204" height="438" rx="30" fill="url(#gSky)"/>
    <g clip-path="url(#scr)">
      <rect x="168" y="62" width="204" height="150" fill="url(#gNavy)"/>
      <circle cx="350" cy="80" r="60" fill="#2CC5B4" opacity=".22"/>
      <path d="M168 164h40l10-24 18 52 10-28h118" fill="none" stroke="#5ADBCB" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" class="ecg" opacity=".85" transform="translate(0 -28)"/>
      <circle cx="202" cy="162" r="25" fill="url(#gTeal)"/><path d="M190 168c2-7 6-10 12-10s10 3 12 10" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round"/><circle cx="202" cy="150" r="7" fill="#fff"/>
      <rect x="238" y="146" width="96" height="11" rx="5.5" fill="#fff"/><rect x="238" y="165" width="64" height="8" rx="4" fill="#fff" opacity=".45"/>
      <rect x="238" y="183" width="40" height="20" rx="10" fill="#FFE3E5"/><text direction="ltr" x="258" y="197" text-anchor="middle" font-family="Poppins,sans-serif" font-weight="700" font-size="11.5" fill="#D64550">O+</text>
      <rect x="283" y="183" width="48" height="20" rx="10" fill="#fff" opacity=".16"/>
    </g>
    <g filter="url(#sh2)">
      <rect x="180" y="228" width="180" height="56" rx="16" fill="#fff"/><circle cx="208" cy="256" r="15" fill="#FFE3E5"/><path d="M208 249v8M208 262v.01" stroke="#D64550" stroke-width="2.4" stroke-linecap="round"/><rect x="232" y="246" width="82" height="9" rx="4.5" fill="#0A1F44" opacity=".85"/><rect x="232" y="262" width="56" height="7" rx="3.5" fill="#0A1F44" opacity=".22"/><rect x="322" y="244" width="26" height="14" rx="7" fill="#FFE3E5"/>
      <rect x="180" y="294" width="180" height="56" rx="16" fill="#fff"/><circle cx="208" cy="322" r="15" fill="#D7F5F0"/><rect x="199" y="318" width="18" height="8" rx="4" fill="none" stroke="#13926F" stroke-width="2" transform="rotate(-40 208 322)"/><rect x="232" y="312" width="70" height="9" rx="4.5" fill="#0A1F44" opacity=".85"/><rect x="232" y="328" width="92" height="7" rx="3.5" fill="#0A1F44" opacity=".22"/>
      <rect x="180" y="360" width="180" height="56" rx="16" fill="#fff"/><circle cx="208" cy="388" r="15" fill="#E8F1FB"/><path d="M202 381h12v14h-12z" fill="none" stroke="#1B4690" stroke-width="2" stroke-linejoin="round"/><rect x="232" y="378" width="76" height="9" rx="4.5" fill="#0A1F44" opacity=".85"/><rect x="232" y="394" width="48" height="7" rx="3.5" fill="#0A1F44" opacity=".22"/>
    </g>
    <rect x="180" y="432" width="180" height="46" rx="16" fill="url(#gTeal)"/><path d="M243 455l6 6 12-13" fill="none" stroke="#0A1F44" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><rect x="270" y="451" width="62" height="8" rx="4" fill="#0A1F44" opacity=".55"/>
    <rect x="228" y="70" width="84" height="20" rx="10" fill="#0b1b3d"/>
  </g>
  <g transform="translate(28 372) rotate(-9)"><g class="qcard" filter="url(#sh)">
    <rect width="214" height="136" rx="18" fill="url(#gNavy)"/><rect width="214" height="136" rx="18" fill="none" stroke="#fff" stroke-opacity=".18"/>
    <circle cx="190" cy="14" r="62" fill="#2CC5B4" opacity=".18"/>
    <rect x="16" y="16" width="22" height="22" rx="7" fill="#fff" opacity=".14"/><path d="M21 28h4l1.6-3.6 2.8 7 1.6-3.4h3" fill="none" stroke="#5ADBCB" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <rect x="16" y="62" width="82" height="11" rx="5.5" fill="#fff"/><rect x="16" y="82" width="56" height="8" rx="4" fill="#fff" opacity=".4"/>
    <rect x="16" y="104" width="38" height="18" rx="9" fill="#2CC5B4"/><text direction="ltr" x="35" y="117" text-anchor="middle" font-family="Poppins,sans-serif" font-weight="700" font-size="10.5" fill="#0A1F44">O+</text>
    <rect x="122" y="30" width="78" height="78" rx="12" fill="#fff"/>${qrAt(q, 128, 36, 66)}
    <path d="M122 44v-8a6 6 0 0 1 6-6h8M200 44v-8a6 6 0 0 0-6-6h-8M122 94v8a6 6 0 0 0 6 6h8M200 94v8a6 6 0 0 1-6 6h-8" fill="none" stroke="#2CC5B4" stroke-width="2.6" stroke-linecap="round" transform="translate(0 -1)"/>
  </g></g>
  <g fill="#5ADBCB" opacity=".9"><path d="M460 120v14M453 127h14" stroke="#5ADBCB" stroke-width="2.4" stroke-linecap="round"/><circle cx="92" cy="170" r="4"/><circle cx="486" cy="330" r="3"/><circle cx="64" cy="300" r="2.5" fill="#fff"/></g>
  <path d="M96 96v12M90 102h12" stroke="#fff" stroke-opacity=".55" stroke-width="2.2" stroke-linecap="round"/>
</svg>`;
}

export const stepArt = {
  1: `<svg viewBox="0 0 300 170" class="art-step" aria-hidden="true"><rect x="52" y="22" width="196" height="132" rx="18" fill="#fff" stroke="#D6E2F0"/><circle cx="92" cy="62" r="20" fill="url(#gTeal)"/><circle cx="92" cy="56" r="6.5" fill="#fff"/><path d="M80 70c2-6 6-8 12-8s10 2 12 8" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round"/><rect x="124" y="50" width="86" height="9" rx="4.5" fill="#0A1F44" opacity=".85"/><rect x="124" y="67" width="54" height="7" rx="3.5" fill="#0A1F44" opacity=".2"/><rect x="72" y="96" width="62" height="24" rx="12" fill="#FFE3E5"/><rect x="82" y="105" width="42" height="6" rx="3" fill="#D64550" opacity=".7"/><rect x="140" y="96" width="62" height="24" rx="12" fill="#D7F5F0"/><rect x="150" y="105" width="42" height="6" rx="3" fill="#13926F" opacity=".7"/><rect x="72" y="126" width="48" height="16" rx="8" fill="#E8F1FB"/><circle cx="244" cy="38" r="15" fill="#2CC5B4"/><path d="M244 31v14M237 38h14" stroke="#0A1F44" stroke-width="3" stroke-linecap="round"/></svg>`,
  2: (q) => `<svg viewBox="0 0 300 170" class="art-step" aria-hidden="true"><path d="M40 150c0-70 50-110 110-110s110 40 110 110" fill="none" stroke="#D6E2F0" stroke-width="2" stroke-dasharray="3 7"/><g transform="translate(70 36) rotate(-6)"><rect width="160" height="100" rx="14" fill="url(#gNavy)"/><circle cx="146" cy="8" r="44" fill="#2CC5B4" opacity=".2"/><rect x="14" y="16" width="16" height="16" rx="5" fill="#fff" opacity=".16"/><rect x="14" y="48" width="58" height="9" rx="4.5" fill="#fff"/><rect x="14" y="64" width="40" height="7" rx="3.5" fill="#fff" opacity=".4"/><rect x="14" y="80" width="30" height="12" rx="6" fill="#2CC5B4"/><rect x="92" y="22" width="56" height="56" rx="9" fill="#fff"/>${qrAt(q, 96, 26, 48)}</g><circle cx="244" cy="44" r="16" fill="#E8F1FB"/><path d="M237 44h14M244 37v14" stroke="#1B4690" stroke-width="2.4" stroke-linecap="round"/></svg>`,
  3: `<svg viewBox="0 0 300 170" class="art-step" aria-hidden="true"><rect x="96" y="14" width="108" height="142" rx="20" fill="#0b1b3d"/><rect x="104" y="22" width="92" height="126" rx="14" fill="url(#gSky)"/><circle cx="150" cy="66" r="24" fill="url(#gTeal)"/><path d="M139 66l8 8 14-16" fill="none" stroke="#0A1F44" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"/><rect x="122" y="102" width="56" height="9" rx="4.5" fill="#0A1F44" opacity=".8"/><rect x="128" y="118" width="44" height="7" rx="3.5" fill="#0A1F44" opacity=".2"/><g transform="translate(206 34)"><circle r="21" fill="#fff" stroke="#D6E2F0"/><circle r="14" fill="none" stroke="#E8F1FB" stroke-width="5"/><path d="M0-14a14 14 0 0 1 12 7" fill="none" stroke="#2CC5B4" stroke-width="5" stroke-linecap="round"/><path d="M0-6v7l5 3" fill="none" stroke="#0A1F44" stroke-width="2" stroke-linecap="round"/></g><g transform="translate(60 120)"><rect x="-26" y="-18" width="52" height="36" rx="12" fill="#fff" stroke="#D6E2F0"/><path d="M-12 0c0-6 5-10 12-10s12 4 12 10" fill="none" stroke="#1B4690" stroke-width="2.4" stroke-linecap="round"/><circle cy="-5" r="3.5" fill="#1B4690"/></g></svg>`,
};

export const authArt = `<svg viewBox="0 0 420 340" class="art-auth" aria-hidden="true"><circle cx="210" cy="170" r="138" fill="#2CC5B4" opacity=".12"/><circle cx="210" cy="170" r="104" fill="none" stroke="#fff" stroke-opacity=".12"/><circle cx="210" cy="170" r="168" fill="none" stroke="#fff" stroke-opacity=".08" stroke-dasharray="2 9"/><g filter="url(#shd)"><path d="M210 62l76 30v56c0 52-32 90-76 106-44-16-76-54-76-106V92z" fill="url(#gNavy)" stroke="#fff" stroke-opacity=".28" stroke-width="2"/></g><path d="M210 62l76 30v56c0 52-32 90-76 106z" fill="#fff" opacity=".06"/><path d="M158 168h30l12-26 22 62 14-36h28" fill="none" stroke="url(#gTeal)" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" class="ecg"/><g fill="#5ADBCB"><circle cx="76" cy="90" r="5"/><circle cx="348" cy="236" r="4"/><circle cx="332" cy="82" r="3" fill="#fff"/></g><path d="M90 252v14M83 259h14" stroke="#fff" stroke-opacity=".6" stroke-width="2.4" stroke-linecap="round"/><defs><filter id="shd" x="-30%" y="-30%" width="160%" height="170%"><feDropShadow dx="0" dy="14" stdDeviation="14" flood-color="#030c20" flood-opacity=".4"/></filter></defs></svg>`;
