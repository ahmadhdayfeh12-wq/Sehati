// End-to-end checks of the security-critical flows. Starts a throwaway server with a temp database.
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'hawiya-'));
const port = 3100 + Math.floor(Math.random() * 500);
const base = `http://localhost:${port}`;
const srv = spawn('node', ['server/server.js'], { env: { ...process.env, PORT: port, DATA_DIR: dir, BASE_URL: base, ADMIN_EMAIL: 'admin@t.test', ADMIN_PASSWORD: 'Admin-Passw0rd!' }, stdio: 'ignore' });
let fails = 0;
const ok = (c, msg) => { console.log(`${c ? 'PASS' : 'FAIL'}  ${msg}`); if (!c) fails++; };

class Client {
  constructor() { this.cookie = ''; this.csrf = ''; }
  async req(method, url, body, headers = {}) {
    const isRaw = Buffer.isBuffer(body);
    const r = await fetch(base + url, { method, headers: { ...(body && !isRaw ? { 'Content-Type': 'application/json' } : {}), ...(this.cookie ? { Cookie: this.cookie } : {}), ...(this.csrf ? { 'X-CSRF': this.csrf } : {}), ...headers }, body: body ? (isRaw ? body : JSON.stringify(body)) : undefined, redirect: 'manual' });
    const sc = r.headers.get('set-cookie'); if (sc) this.cookie = sc.split(';')[0];
    const buf = Buffer.from(await r.arrayBuffer());
    let json = null; try { json = JSON.parse(buf.toString()); } catch {}
    return { status: r.status, json, buf, headers: r.headers };
  }
  async me() { const r = await this.req('GET', '/api/me'); this.csrf = r.json.csrf || ''; return r.json.user; }
  async login(email, password) { const r = await this.req('POST', '/api/login', { email, password }); await this.me(); return r; }
}
const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(40, 1)]);

try {
  for (let i = 0; i < 50; i++) { try { await fetch(base + '/api/healthz'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }

  // --- registration, weak passwords, duplicate
  const fam = new Client();
  let r = await fam.req('POST', '/api/register', { role: 'caregiver', email: 'son@t.test', password: 'short', name: 'Son' });
  ok(r.status === 400, 'weak password rejected');
  r = await fam.req('POST', '/api/register', { role: 'caregiver', email: 'son@t.test', password: 'Long-enough-pw1', name: 'Son Abroad' });
  ok(r.status === 200, 'caregiver registers');
  await fam.me();
  r = await new Client().req('POST', '/api/register', { role: 'caregiver', email: 'SON@t.test', password: 'Long-enough-pw1', name: 'x' });
  ok(r.status === 409, 'duplicate email rejected (case-insensitive)');
  r = await fam.req('POST', '/api/patients', { full_name: 'Mother Test', dob: '1950-01-01', blood_group: 'A+' }, { 'X-CSRF': '' });
  ok(r.status === 403, 'CSRF header required on writes');
  r = await fam.req('POST', '/api/patients', { full_name: 'Mother Test', dob: '1950-01-01', blood_group: 'A+' });
  ok(r.status === 200, 'caregiver creates a profile'); const pid = r.json.id;
  r = await fam.req('POST', `/api/patients/${pid}/allergies`, { substance: 'Penicillin', severity: 'severe' });
  ok(r.status === 200, 'add allergy');
  r = await fam.req('POST', `/api/patients/${pid}/medications`, { name: 'Metformin', dose: '500 mg', active: true, route: 'oral' });
  ok(r.status === 200, 'add medication');
  r = await fam.req('POST', `/api/patients/${pid}/conditions`, { name: 'Diabetes' });
  r = await fam.req('POST', `/api/patients/${pid}/contacts`, { name: 'Son', phone: '+961 70 000000', is_primary: true });
  ok(r.status === 200, 'add contact');
  r = await fam.req('POST', `/api/patients/${pid}/contacts`, { name: 'Bad', phone: 'abc' });
  ok(r.status === 400, 'invalid phone rejected');

  // --- QR: random token only
  r = await fam.req('GET', `/api/patients/${pid}/qr`);
  const url = r.json.url; const token = url.split('/s/')[1];
  ok(token.length >= 43 && !/Mother|1950|Penicillin/i.test(url), 'QR URL holds only a random token');
  ok(r.json.svg.startsWith('<svg'), 'QR svg generated');

  // --- uploads
  r = await fam.req('POST', `/api/patients/${pid}/documents`, Buffer.from('<script>alert(1)</script>'), { 'X-Title': 'evil', 'Content-Type': 'application/pdf' });
  ok(r.status === 400, 'upload with fake content-type rejected (magic bytes checked)');
  r = await fam.req('POST', `/api/patients/${pid}/documents`, png, { 'X-Title': encodeURIComponent('Chest X-ray'), 'X-Category': 'xray', 'Content-Type': 'image/png' });
  ok(r.status === 200, 'valid PNG upload accepted'); const docId = r.json.id;
  const stored = fs.readdirSync(path.join(dir, 'uploads'));
  ok(stored.length === 1 && !fs.readFileSync(path.join(dir, 'uploads', stored[0])).includes(png.subarray(0, 8)), 'stored file is encrypted at rest');
  r = await fam.req('GET', `/api/documents/${docId}/file`);
  ok(r.status === 200 && r.buf.equals(png), 'owner downloads document intact');

  // --- outsiders cannot touch the profile
  const other = new Client();
  await other.req('POST', '/api/register', { role: 'caregiver', email: 'other@t.test', password: 'Long-enough-pw1', name: 'Other' }); await other.me();
  r = await other.req('GET', `/api/patients/${pid}`);
  ok(r.status === 404, "another family cannot read someone else's profile");
  r = await other.req('GET', `/api/documents/${docId}/file`);
  ok(r.status === 404, "another family cannot read someone else's document");

  // --- doctor verification
  const dr = new Client();
  r = await dr.req('POST', '/api/register', { role: 'doctor', email: 'dr@t.test', password: 'Long-enough-pw1', name: 'Dr. Test', license_no: 'L-1', specialty: 'Cardiology' });
  ok(r.status === 200, 'doctor registers'); await dr.me();
  r = await dr.req('GET', `/api/scan/${token}`);
  ok(r.status === 403 && r.json.error === 'doctor_not_verified', 'unverified doctor cannot scan');
  const adm = new Client(); r = await adm.login('admin@t.test', 'Admin-Passw0rd!'); ok(r.status === 200, 'admin logs in');
  r = await adm.req('GET', '/api/admin/doctors?status=pending'); const drId = r.json.doctors.find((d) => d.email === 'dr@t.test')?.id;
  ok(!!drId, 'pending doctor visible to admin');
  r = await adm.req('GET', `/api/patients/${pid}`); ok(r.status === 403, 'admin cannot read patient medical data');
  r = await adm.req('POST', `/api/admin/doctors/${drId}`, { status: 'approved' }); ok(r.status === 200, 'admin verifies doctor');
  await dr.me(); // session user refreshed server-side

  // --- scan: no data until the patient consents
  r = await dr.req('GET', `/api/scan/${token}`);
  ok(r.status === 200 && r.json.access === 'none' && r.json.patient.display === 'Mother T.' && !('allergies' in r.json), 'scan reveals only a masked name');
  r = await dr.req('GET', `/api/doctor/patients/${pid}/record`); ok(r.status === 403, 'record denied without grant');
  r = await dr.req('GET', `/api/documents/${docId}/file`); ok(r.status === 403, 'document denied without grant');
  r = await new Client().req('GET', `/api/scan/${token}`); ok(r.status === 401, 'anonymous scan reveals nothing');
  r = await dr.req('GET', '/api/scan/' + 'x'.repeat(43)); ok(r.status === 404, 'unknown token rejected');

  // --- consent flow
  r = await dr.req('POST', `/api/scan/${token}/request`); ok(r.json.access === 'pending', 'doctor requests access');
  r = await fam.req('GET', `/api/patients/${pid}/grants`); const gid = r.json.grants[0].id;
  r = await fam.req('POST', `/api/patients/${pid}/grants/${gid}`, { decision: 'approve', hours: 24 }); ok(r.status === 200, 'family approves for 24h');
  r = await dr.req('GET', `/api/doctor/patients/${pid}/record`);
  ok(r.status === 200 && r.json.medications.length === 1 && r.json.documents.length === 1, 'doctor sees full record after consent');
  r = await dr.req('GET', `/api/documents/${docId}/file`); ok(r.status === 200, 'doctor opens document after consent');
  r = await fam.req('POST', `/api/patients/${pid}/grants/${gid}`, { decision: 'revoke' });
  r = await dr.req('GET', `/api/doctor/patients/${pid}/record`); ok(r.status === 403, 'access ends immediately when revoked');

  // --- emergency access
  r = await dr.req('POST', `/api/scan/${token}/emergency`, { reason: 'cardiac', justification: 'short', confirm: true }); ok(r.status === 400, 'emergency needs a real justification');
  r = await dr.req('POST', `/api/scan/${token}/emergency`, { reason: 'cardiac', justification: 'Patient collapsed in the ER, unresponsive', confirm: true });
  ok(r.status === 200 && r.json.allergies[0].substance === 'Penicillin' && r.json.contacts.length === 1, 'emergency returns minimal data');
  ok(!('documents' in r.json) && !('city' in r.json.patient) && !('dob' in r.json.patient), 'emergency view excludes documents and extra identifiers');

  // --- audit visible to patient
  r = await fam.req('GET', `/api/patients/${pid}/access-log`);
  const acts = r.json.log.map((x) => x.action);
  ok(['scan', 'access_requested', 'grant_approve', 'view_record', 'emergency_access', 'document_viewed'].every((a) => acts.includes(a)), 'patient sees every access in their history');
  const em = r.json.log.find((x) => x.action === 'emergency_access');
  ok(em.actor_name === 'Dr. Test' && JSON.parse(em.detail).reason === 'cardiac', 'emergency entry shows who and why');
  r = await adm.req('GET', '/api/admin/audit'); ok(r.json.chain.ok === true && r.json.chain.checked > 10, 'audit hash chain verifies');

  // --- QR rotation invalidates the old card
  r = await fam.req('POST', `/api/patients/${pid}/qr/rotate`); ok(r.status === 200, 'family rotates QR');
  r = await dr.req('GET', `/api/scan/${token}`); ok(r.status === 404, 'old QR no longer works');

  // --- lockout and logout
  const bf = new Client(); for (let i = 0; i < 5; i++) await bf.req('POST', '/api/login', { email: 'son@t.test', password: 'wrong-wrong-1' });
  r = await bf.req('POST', '/api/login', { email: 'son@t.test', password: 'Long-enough-pw1' }); ok(r.status === 429, 'account locks after 5 failed logins');
  r = await fam.req('POST', '/api/logout'); r = await fam.req('GET', `/api/patients/${pid}`); ok(r.status === 401, 'logout ends the session');

  // --- headers
  r = await new Client().req('GET', '/'); ok(/script-src 'self'/.test(r.headers.get('content-security-policy')) && r.headers.get('referrer-policy') === 'no-referrer', 'security headers present');
  r = await new Client().req('GET', '/..%2f..%2fserver%2fconfig.js'); ok(r.status !== 200 || r.buf.toString().includes('<!doctype') || r.buf.toString().includes('<!DOCTYPE'), 'path traversal blocked');
} catch (e) { console.error(e); fails++; }
srv.kill();
fs.rmSync(dir, { recursive: true, force: true });
console.log(fails ? `\n${fails} check(s) FAILED` : '\nAll checks passed');
process.exit(fails ? 1 : 0);
