// Fails if a key used in the UI is missing in English or Arabic, or if the two languages differ.
import fs from 'node:fs';
import { DICT } from '../public/i18n.js';
const src = fs.readFileSync(new URL('../public/app.js', import.meta.url), 'utf8');
const keys = new Set([...src.matchAll(/\bt\('([^']+)'/g)].map((m) => m[1]).filter((k) => !k.endsWith('.')));
const dyn = {
  'em.': ['1','2','3'], 'how.': ['1.t','1.d','2.t','2.d','3.t','3.d'], 'pr.': ['1.t','1.d','2.t','2.d','3.t','3.d','4.t','4.d'],
  'tab.': ['overview','conditions','allergies','medications','contacts','documents','qr','access','sharing'],
  'hint.': ['conditions','allergies','medications','contacts','documents'], 'empty.': ['conditions','allergies','medications','contacts','documents'], 'add.': ['conditions','allergies','medications','contacts','documents'],
  'o.': ['active','resolved','mild','moderate','severe','oral','injection','inhaled','topical','drops','other','current','stopped'],
  'c.': ['xray','mri','ct','ultrasound','lab','prescription','discharge','report','vaccination','other'],
  'r.': ['unconscious','cardiac','respiratory','trauma','confused','other'], 'gs.': ['pending','active','denied','revoked','expired','approved','rejected'],
  'role.': ['caregiver','patient','doctor','admin','caregiver.d','patient.d','doctor.d'], 'share.': ['owner','caregiver'],
  'f.': ['email','password','name','phone','dob','blood_group','city','license_no','specialty','facility','full_name','warnings','diagnosed_year','status','notes','substance','reaction','severity','dose','frequency','route','start_date','end_date','prescriber','active','relation','is_primary','title','category','file'],
};
for (const [p, l] of Object.entries(dyn)) l.forEach((x) => keys.add(p + x));
let bad = 0;
for (const lang of ['en', 'ar']) for (const k of keys) if (!(k in DICT[lang])) { console.log(`missing [${lang}] ${k}`); bad++; }
for (const k of Object.keys(DICT.en)) if (!(k in DICT.ar)) { console.log(`ar lacks ${k}`); bad++; }
for (const k of Object.keys(DICT.ar)) if (!(k in DICT.en)) { console.log(`en lacks ${k}`); bad++; }
console.log(bad ? `${bad} translation problem(s)` : `i18n OK: ${Object.keys(DICT.en).length} strings in English and Arabic`);
process.exit(bad ? 1 : 0);
