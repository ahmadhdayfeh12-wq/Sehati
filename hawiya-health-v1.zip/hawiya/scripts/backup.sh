#!/bin/sh
# Consistent backup of the database and uploaded files. Run daily from cron, copy the result OFF the server.
# Usage: DATA_DIR=/data ./scripts/backup.sh /backups
set -e
DATA_DIR="${DATA_DIR:-./data}"; OUT="${1:-./backups}"; STAMP=$(date +%Y%m%d-%H%M%S)
mkdir -p "$OUT"
node -e "const {DatabaseSync}=require('node:sqlite');const d=new DatabaseSync('$DATA_DIR/hawiya.db');d.exec(\"VACUUM INTO '$OUT/hawiya-$STAMP.db'\")"
tar -czf "$OUT/uploads-$STAMP.tar.gz" -C "$DATA_DIR" uploads
echo "Backup written to $OUT (keep DATA_KEY separately, backups are useless without it)"
